package com.lakala.moss;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.lakala.moss.api.ApiReq;
import com.lakala.moss.api.ApiRes;
import com.lakala.moss.api.params.LocationInfo;
import com.lakala.moss.api.request.*;
import com.lakala.moss.api.response.*;
import com.lakala.moss.service.IMossApiService;
import com.lakala.moss.service.impl.MossApiServiceImpl;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Type;

/**
 * @author Stephen yu
 * @description: 测试类
 * @date 2025-02-21
 */
public class MossApiTest {

    private static final Logger logger = LoggerFactory.getLogger(MossApiTest.class);

    // 订单支付-拉起收银台
    @Test
    public void testOrderPayCounter(){
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        IMossApiService mossApi = new MossApiServiceImpl();
        OrderPayReq req = new OrderPayReq();
        req.setOrder_no("DemoMOSS20250225000001");
        req.setTotal_amount("1");
        req.setMer_no("M00000036");
        req.setRemark("测试");
        req.setNotify_url("");
        req.setPay_scene("0");
        req.setAccount_type("ALIPAY,WECHAT,UQRCODEPAY");
        req.setSubject("测试标题");
        req.setOrder_eff_time("300");
        req.setCallback_url("https://www.baidu.com/");
        ApiRes<OrderPayRes> res = mossApi.OrderPay(req);
        logger.info("res={}",gson.toJson(res));
    }
    // 订单支付-独立支付
    @Test
    public void testOrderPay(){
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        IMossApiService mossApi = new MossApiServiceImpl();
        OrderPayReq req = new OrderPayReq();
        req.setOrder_no("DemoMOSS20250225000001");
        req.setTotal_amount("1");
        req.setMer_no("M00000036");
        req.setRemark("测试");
        req.setNotify_url("");
        req.setPay_scene("1");
        req.setAccount_type("UQRCODEPAY");
        req.setSubject("测试标题");
        req.setOrder_eff_time("15");
        req.setTrans_type("51");
        req.setUser_id("olpr-0sYaDrxaT5GmLUgUenVcDPo");
        LocationInfo location_info = new LocationInfo();
        location_info.setRequest_ip("36.45.36.95");
        location_info.setBase_station("00 6361   58130");
        location_info.setLocation("+37.123456789,-121.123456789");
        req.setLocation_info(location_info);
        ApiRes<OrderPayRes> res = mossApi.OrderPay(req);
        logger.info("res={}",gson.toJson(res));
    }
    // 订单查询
    @Test
    public void testOrderQryList(){
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        IMossApiService mossApi = new MossApiServiceImpl();
        OrderQryListReq req = new OrderQryListReq();
        req.setOrder_no("DemoMOSS20250225000001");
        req.setPay_serial("0bf31ad8e73e4e548960599b70d9b591");
        ApiRes<OrderQryListRes> res = mossApi.OrderQryList(req);
        logger.info("res={}",gson.toJson(res));
    }
    // 订单关单
    @Test
    public void testOrderCls(){
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        IMossApiService mossApi = new MossApiServiceImpl();
        OrderClsReq req = new OrderClsReq();
        req.setOrigin_order_no("DemoMOSS20250225000001");
        LocationInfo location_info = new LocationInfo();
        location_info.setRequest_ip("36.45.36.95");
        location_info.setBase_station("00 6361   58130");
        location_info.setLocation("+37.123456789,-121.123456789");
        req.setLocation_info(location_info);
        ApiRes<OrderClsRes> res = mossApi.OrderCls(req);
        logger.info("res={}",gson.toJson(res));
    }
    // 订单退款
    @Test
    public void testOrderRefund(){
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        IMossApiService mossApi = new MossApiServiceImpl();
        OrderRefundReq req = new OrderRefundReq();
        req.setOrder_no("RefundMOSS20250225000001");
        req.setOrigin_order_no("DemoMOSS20250225000001");
        req.setOrigin_pay_serial("0bf31ad8e73e4e548960599b70d9b591");
        req.setRefund_amount("1");
        req.setRefund_reason("测试退款");
        LocationInfo location_info = new LocationInfo();
        location_info.setRequest_ip("36.45.36.95");
        location_info.setBase_station("00 6361   58130");
        location_info.setLocation("+37.123456789,-121.123456789");
        req.setLocation_info(location_info);
        ApiRes<OrderRefundRes> res = mossApi.OrderRefund(req);
        logger.info("res={}",gson.toJson(res));
    }
    // 订单查询-退款
    @Test
    public void testOrderQryRefund(){
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        IMossApiService mossApi = new MossApiServiceImpl();
        OrderQryListReq req = new OrderQryListReq();
        req.setOrder_no("RefundMOSS20250225000001");
        ApiRes<OrderQryListRes> res = mossApi.OrderQryList(req);
        logger.info("res={}",gson.toJson(res));
    }
    // 订单通知
    @Test
    public void testOrderNotice(){
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        Type type = new TypeToken<ApiReq<OrderNoticeReq>>() {}.getType();
        IMossApiService mossApi = new MossApiServiceImpl();
        String request = "{\"head\":{\"requestTime\":\"20250227161640\",\"versionId\":\"1.0\",\"org\":\"000000000001\",\"serviceSn\":\"94452612AAB545149ED020431DE5C5F3\",\"serviceId\":\"lfops.moss.order.ntc\",\"channelId\":\"01\",\"businessChannel\":\"C00000001\",\"sid\":\"94452612AAB545149ED020431DE5C5F3\",\"accessToken\":\"\"},\"sign\":\"iZu2qma07bCjelm5jMuhtoXXG5/uqPSE/TgCGU6YerVpt7fwIqX9Y+wBTdZr8EXZF4CiU79usuVOi18SxvbXORXMsDUUlLL8E5eIvjh/xuaiYC/IXeOMC1CM+IbD9ql9n4/2E3f/wn5+OOtOgZM/HeVME7lsyndGvx6Iqof+kn0=\",\"requestEncrypted\":\"l+ULAxGYu3FFUIxAvY5h8f3qMoolXISOzdKp80zR2Jc016IQtVfKikWq6BPAaqzzLgL4rIWrQfr316iQVRQcN3OhIQS7ViRseeE7S1NVXSPWhypVWwnas6tfiURYqm+yydIiQ0e0FvLPIR6Hf909d3QdiDWoRQFXyzIVwjTnPbARk01NccPOLk/0HtEqoIPbmI/hOQYoxzY22Dj+WetAcRNdzaOL8vbFByTpHYSKu2teg+irEKLbs4VYpi0husKAT6eqyrX8ZTxMCeGhwsiLku68BOz7ddeA7aV/JJDOXDtd/qGjOhQIZL8anMbaN9CGY3xodCweGXRcYInc6frV0DhHu7FKO60//Q6zMwVwPp4qcA9mLpvclC37uE3CD5JJaOdyfVV2f4NgFa5lnFBYRXIicWTTQlPaNgZw4n9j61M7eWhFFzPqwvcGxcYxCcYrVmVZNr/KGHV4hGWuvjI9tiPJ1Uu5ZpHwkL75H+921uJLDmoshmD6VlgfPW4mmXY1QeeUTnQVHiIRN3BQ/c4ZjiAcxLEpQV4a26Vh5PDviQM0C6kZdLSGFmbMsMawcHV7LfzMbi2PbGGwWs/+sXKbb6m9bW1yH7sUsT9ScA0oJCDeRtpAO4yfnejU4b9Jj11vD9Wi7hilF1SMKAHKl3zzzmtRaN74oAYDCz5Zuo9bqZxJ/0ktBFfnIZ5aCUAiW6IFeaRsmQ2jXTO7JbDSfX5LfgA0lE1F7OV/Q7KC4TaVyz2XQ3FNztB9xDPY2uaNdetRIYk+71/cXmYcUIJPeqt0FcP7DXDzAKBkWbZh7MvC/7pDwBm6oW06HKDWiK2qJjRYi8k9Xzo+Q2T0nBpLLdMVKIDmEo1hJm13PC8ovl68kSvXEMSqs0D6snXxI+Op9QvkVjr3Q6fEbl3gKofPnssTzkmYLqK5hQ4AamiMNh5tC7fyd9T+w88iz6uuxQ/WcJ/q+FA6nLcjbkAouWiubU1ZCdYux9QkRaG4iZUJZ0Vo7b/7s1yg86+GjoJ2nsETU8fX\"}";
        ApiReq<OrderNoticeReq> req = gson.fromJson(request, type);
        ApiRes<OrderNoticeRes> res = mossApi.OrderNotice(req);
        logger.info("res={}",gson.toJson(res));
    }
    // 申请对账单
    @Test
    public void testOrderChkApply(){
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        IMossApiService mossApi = new MossApiServiceImpl();
        OrderChkApplyReq req = new OrderChkApplyReq();
        req.setTran_date("20250225");
        req.setApply_order_no("AONMOSS20250226000003");
        ApiRes<OrderChkApplyRes> res = mossApi.OrderChkApply(req);
        logger.info("res={}",gson.toJson(res));
    }
    // 用户标识查询
    @Test
    public void testUseridQry(){
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        IMossApiService mossApi = new MossApiServiceImpl();
        UseridQryReq req = new UseridQryReq();
        req.setMer_no("M00000036");
        req.setAuth_code("5oqA5pyv5pSv5oyB5Zui6Zif6Ze16Z2S");
        req.setApp_up_identifier("UnionPay/1.0 ICBCeLife");
        ApiRes<UseridQryRes> res = mossApi.UseridQry(req);
        logger.info("res={}",gson.toJson(res));
    }
    // 对账单下载
    @Test
    public void testChkDownload(){
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        IMossApiService mossApi = new MossApiServiceImpl();
        String downUrl = "https://jrt.wsmsd.cn/lfpf-sch/chkfile/download?apply_order_no=AONMOSS20250226000003&file_name=F20250225_TRAN_CHECK_C00000001_01.xls";
        String localDir = "d:/localpath/data/";
        String localFileName = "F20250225_TRAN_CHECK_C00000001_01.xls";
        boolean res = mossApi.ChkDownload(downUrl,localDir,localFileName);
        logger.info("res={}",res);
    }

}
