package com.lakala.moss.api.params;

/**
 * 请求参数-拆单信息
 *
 * @author Stephen yu
 * @date 2025-04-11
 */
public class SplitInfo {
    // 子单支付流水号
    private String sub_pay_serial;
    // 商户号
    private String mer_no;
    // 金额,单位分
    private String amount;
    // 子单对账单流水号
    private String sub_log_no;
    // 以下为合单退款特有字段
    // 申请退款金额,单位分
    private String refund_amount;
    // 原子单支付流水号
    private String origin_sub_pay_serial;
    // 仅交易类型为PREFUND-退款时存在。表示子单退货状态 SUCCESS-交易成功
    private String sub_trade_state;

    public String getSub_pay_serial() {
        return sub_pay_serial;
    }

    public void setSub_pay_serial(String sub_pay_serial) {
        this.sub_pay_serial = sub_pay_serial;
    }

    public String getMer_no() {
        return mer_no;
    }

    public void setMer_no(String mer_no) {
        this.mer_no = mer_no;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getSub_log_no() {
        return sub_log_no;
    }

    public void setSub_log_no(String sub_log_no) {
        this.sub_log_no = sub_log_no;
    }

    public String getRefund_amount() {
        return refund_amount;
    }

    public void setRefund_amount(String refund_amount) {
        this.refund_amount = refund_amount;
    }

    public String getOrigin_sub_pay_serial() {
        return origin_sub_pay_serial;
    }

    public void setOrigin_sub_pay_serial(String origin_sub_pay_serial) {
        this.origin_sub_pay_serial = origin_sub_pay_serial;
    }

    public String getSub_trade_state() {
        return sub_trade_state;
    }

    public void setSub_trade_state(String sub_trade_state) {
        this.sub_trade_state = sub_trade_state;
    }
}
