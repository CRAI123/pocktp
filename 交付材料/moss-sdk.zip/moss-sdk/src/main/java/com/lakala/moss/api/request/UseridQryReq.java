package com.lakala.moss.api.request;

/**
 * 请求参数-用户标识查询
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class UseridQryReq {

    // 商户号，平台客户下所发展的商户，通过MOSS平台新增商户产生，M+8位数字；
    private String mer_no;
    // 付款方返回的临时授权码，一次有效。
    //银联云闪付APP访问收单商户H5页面，收款方返回302重定向地址。
    //具体格式如下： “ https://qr.95516.com/qrcGtwWeb-web/api/userAuth?version=1.0.0&redirectUrl=收单商户接收处理结果的地址，需进行URLEncode”，成功后返回临时授权码
    private String auth_code;
    // 银联支付标识.收款方识别HTTP请求User Agent中包含银联支付标识，格式为“UnionPay/<版本号> <App标识>”，注意APP标识仅支持字母和数字,例：UnionPay/1.0 ICBCeLife
    private String app_up_identifier;

    public String getMer_no() {
        return mer_no;
    }

    public void setMer_no(String mer_no) {
        this.mer_no = mer_no;
    }

    public String getAuth_code() {
        return auth_code;
    }

    public void setAuth_code(String auth_code) {
        this.auth_code = auth_code;
    }

    public String getApp_up_identifier() {
        return app_up_identifier;
    }

    public void setApp_up_identifier(String app_up_identifier) {
        this.app_up_identifier = app_up_identifier;
    }
}
