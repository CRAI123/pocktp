package com.lakala.moss.util;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.ArrayUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.crypto.Cipher;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * @author Stephen yu
 * @description: 密钥工具类
 * @date 2025-02-21
 */
public class SecurityUtil {
    private static final Logger logger = LoggerFactory.getLogger(SecurityUtil.class);
    private static final String SOLT = "0123456789ABCDEF";
    private static final Provider PROVIDER = new BouncyCastleProvider();
    private static final String SIGN_VERIFY_ALGORITHM = "SHA1withRSA";
    private static final String ENCRYPTD_ECRYPT_ALGORITHM = "RSA/None/PKCS1Padding";
    private static final int RSA_KEY_LENGHTH = 1024;

    private static final String ALGORITHM = "RSA";

    private SecurityUtil() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * 从字符串中加载公钥
     * 
     * @param publicKeyStr 公钥数据字符串
     * @throws Exception 加载公钥时产生的异常
     */
    private static PublicKey loadPublicKey(String publicKeyStr) throws Exception {
        try {
            byte[] buffer = Base64.decodeBase64(publicKeyStr.getBytes(StandardCharsets.UTF_8));
            KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(buffer);
            return keyFactory.generatePublic(keySpec);
        } catch (Exception ex) {
            logger.warn("load public key exception:", ex);
            throw ex;
        }
    }

    private static PrivateKey loadPrivateKey(String privateKeyStr) throws Exception {
        try {
            byte[] buffer = Base64.decodeBase64(privateKeyStr.getBytes(StandardCharsets.UTF_8));
            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(buffer);
            KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
            return keyFactory.generatePrivate(keySpec);
        } catch (Exception ex) {
            logger.warn("load private key exception:", ex);
            throw ex;
        }
    }

    /** * 用公钥验证签名的正确性 * * @param message * @param signStr * @return * @throws Exception */
    public static boolean verify(String message, String signStr, String publicKeyStr) {
        if (message == null || signStr == null || publicKeyStr == null) {
            return false;
        }
        try {
            PublicKey key = loadPublicKey(publicKeyStr);
            Signature signetcheck = Signature.getInstance(SIGN_VERIFY_ALGORITHM);
            signetcheck.initVerify(key);
            signetcheck.update(message.getBytes(StandardCharsets.UTF_8));
            return signetcheck
                    .verify(Base64.decodeBase64(signStr.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception ex) {
            logger.warn("verify [{}] sign [{}]  exception:", message, signStr, ex);
            return false;
        }

    }

    public static String sign(String message, String privateKeyStr) {
        try {
            PrivateKey key = loadPrivateKey(privateKeyStr);
            Signature signetcheck = Signature.getInstance(SIGN_VERIFY_ALGORITHM);
            signetcheck.initSign(key);
            signetcheck.update(message.getBytes(StandardCharsets.UTF_8));
            return new String(Base64.encodeBase64(signetcheck.sign()), StandardCharsets.UTF_8);
        } catch (Exception ex) {
            logger.warn("sign message [{}] exception:", message, ex);
            return "";
        }

    }

    public static String encryptBase64(String messageBase64, String publicKeyStr) {
        byte[] message = Base64.decodeBase64(messageBase64.getBytes(StandardCharsets.UTF_8));
        byte[] encrypted = encrypt(message, publicKeyStr);
        byte[] encryptBase64 = Base64.encodeBase64(encrypted);
        return new String(encryptBase64, StandardCharsets.UTF_8);
    }

    public static String encryptInBytesOutBase64(byte[] message, String publicKeyStr) {
        byte[] encrypted = encrypt(message, publicKeyStr);
        byte[] encryptBase64 = Base64.encodeBase64(encrypted);
        return new String(encryptBase64, StandardCharsets.UTF_8);
    }

    public static String encryptInStringOutBase64(String message, String publicKeyStr) {
        byte[] encrypted = encrypt(message.getBytes(StandardCharsets.UTF_8), publicKeyStr);
        byte[] encryptBase64 = Base64.encodeBase64(encrypted);
        return new String(encryptBase64, StandardCharsets.UTF_8);
    }


    public static String decryptBase64(String messageBase64, String privateKeyStr) {
        byte[] message = Base64.decodeBase64(messageBase64.getBytes(StandardCharsets.UTF_8));
        byte[] decrypted = decrypt(message, privateKeyStr);
        byte[] decryptBase64 = Base64.encodeBase64(decrypted);
        return new String(decryptBase64, StandardCharsets.UTF_8);
    }

    public static byte[] decryptInBase64OutBytes(String messageBase64, String privateKeyStr) {
        byte[] message = Base64.decodeBase64(messageBase64.getBytes(StandardCharsets.UTF_8));
        return decrypt(message, privateKeyStr);
    }

    public static String decryptInBase64OutString(String messageBase64, String privateKeyStr) {
        byte[] message = Base64.decodeBase64(messageBase64.getBytes(StandardCharsets.UTF_8));
        return new String(decrypt(message, privateKeyStr), StandardCharsets.UTF_8);
    }

    // ref: https://blog.csdn.net/taoxin52/article/details/53782470
    public static byte[] encrypt(byte[] message, String publicKeyStr) {
        if (message == null || publicKeyStr == null || message.length == 0) {
            return new byte[0];
        }
        try {
            PublicKey key = loadPublicKey(publicKeyStr);
            Cipher cipher = Cipher.getInstance(ENCRYPTD_ECRYPT_ALGORITHM, PROVIDER);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encryptBS = null;
            int plaintextLen = RSA_KEY_LENGHTH / 8 - 11;
            for (int i = 0; i < message.length; i += plaintextLen) {
                byte[] doFinal = cipher.doFinal(ArrayUtils.subarray(message, i, i + plaintextLen));
                encryptBS = ArrayUtils.addAll(encryptBS, doFinal);
            }
            return encryptBS;
        } catch (Exception ex) {
            logger.info("encrypt message [{}] exception:", byteArrayToHexString(message), ex);
            return new byte[0];
        }
    }

    public static byte[] decrypt(byte[] message, String privateKeyStr) {
        if (message == null || privateKeyStr == null || message.length == 0) {
            return new byte[0];
        }
        try {
            PrivateKey key = loadPrivateKey(privateKeyStr);
            Cipher cipher = Cipher.getInstance(ENCRYPTD_ECRYPT_ALGORITHM, PROVIDER);
            cipher.init(Cipher.DECRYPT_MODE, key);
            int cipherTextLen = RSA_KEY_LENGHTH / 8;
            byte[] decryptBS = null;
            for (int i = 0; i < message.length; i += cipherTextLen) {
                byte[] doFinal = cipher.doFinal(ArrayUtils.subarray(message, i, i + cipherTextLen));
                decryptBS = ArrayUtils.addAll(decryptBS, doFinal);
            }
            return decryptBS;
        } catch (Exception ex) {
            logger.info("decrypt message [{}] exception:", byteArrayToHexString(message), ex);
            return new byte[0];
        }
    }



    private static String byteArrayToHexString(byte[] b) {
        StringBuilder sb = new StringBuilder(64);
        for (int i = 0; i < b.length; i++) {
            sb.append(SOLT.charAt(b[i] >>> 4 & 0x0F));
            sb.append(SOLT.charAt(b[i] & 0x0F));
        }
        return sb.toString();

    }


    /**
     * 哈希函数
     * 
     * @param algorithm String MD5/SHA
     * @param b byte[]
     * @return byte[]
     */
    private static byte[] hashData(String algorithm, byte[] b) throws NoSuchAlgorithmException {

        MessageDigest md = MessageDigest.getInstance(algorithm);
        md.update(b);
        return md.digest();
    }

    /**
     * 制作MD5
     * 
     * @param source String
     * @return byte[]
     */
    public static String md5(String source) {
        return md5(source.getBytes(StandardCharsets.UTF_8));
    }

    public static String md5(byte[] b) {
        try {
            byte[] a = hashData("MD5", b);
            return byteArrayToHexString(a);
        } catch (NoSuchAlgorithmException ex) {
            logger.warn("calculate [{}] md5 exception:", byteArrayToHexString(b));
            return "";
        }
    }

    public static String getSignSrc(Map<String, String> secMap, boolean isUseKey, String split) {
        StringBuilder content = new StringBuilder(512);
        List<String> keys = new ArrayList<>(secMap.keySet());
        Collections.sort(keys);
        for (int i = 0; i < keys.size(); i++) {
            Object key = keys.get(i);
            if ("sign".equals(key)) {
                continue;
            }
            Object value = secMap.get(key);
            if (value instanceof String) {
                if (isUseKey) {
                    content.append((i == 0 ? "" : split) + key + "=" + (String) value);
                } else {
                    content.append((i == 0 ? "" : split) + (String) value);
                }
            }
        }
        return content.toString();
    }

    public static String getSignSrcSkipNull(Map<String, String> secMap, boolean isUseKey,
            String split) {
        StringBuilder content = new StringBuilder(512);
        List<String> keys = new ArrayList<>(secMap.keySet());
        Collections.sort(keys);
        for (int i = 0; i < keys.size(); i++) {
            Object key = keys.get(i);
            if ("sign".equals(key)) {
                continue;
            }
            Object value = secMap.get(key);
            if (value instanceof String) {
                if ("".equals(value)) {
                    continue;
                }
                if (isUseKey) {
                    content.append((i == 0 ? "" : split) + key + "=" + (String) value);
                } else {
                    content.append((i == 0 ? "" : split) + (String) value);
                }
            }
        }
        return content.toString();
    }
}
