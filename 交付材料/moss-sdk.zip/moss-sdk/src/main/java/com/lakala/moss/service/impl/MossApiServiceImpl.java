package com.lakala.moss.service.impl;

import com.lakala.moss.api.*;
import com.lakala.moss.api.request.*;
import com.lakala.moss.api.response.*;
import com.lakala.moss.service.IMossApiService;
import com.lakala.moss.util.CustomUrlUtil;

/**
 * @author Stephen yu
 * @description: api服务接口实现
 * @date 2025-02-21
 */
public class MossApiServiceImpl extends BaseService implements IMossApiService {
    @Override
    public ApiRes<OrderPayRes> OrderPay(OrderPayReq req) {
        return super.postService(req,OrderPayRes.class,"lfops.moss.order.pay");
    }
    @Override
    public ApiRes<OrderQryListRes> OrderQryList(OrderQryListReq req) {
        return super.postService(req,OrderQryListRes.class,"lfops.moss.order.qry");
    }
    @Override
    public ApiRes<OrderClsRes> OrderCls(OrderClsReq req) {
        return super.postService(req,OrderClsRes.class,"lfops.moss.order.cls");
    }
    @Override
    public ApiRes<OrderRefundRes> OrderRefund(OrderRefundReq req) {
        return super.postService(req,OrderRefundRes.class,"lfops.moss.order.ref");
    }
    @Override
    public ApiRes<OrderChkApplyRes> OrderChkApply(OrderChkApplyReq req) {
        return super.postService(req,OrderChkApplyRes.class,"lfops.moss.order.chk.apply");
    }
    @Override
    public ApiRes<UseridQryRes> UseridQry(UseridQryReq req) {
        return super.postService(req,UseridQryRes.class,"lfops.moss.userid.qry");
    }

    @Override
    public boolean ChkDownload(String urlPath, String localDir, String localFileName) {
        return CustomUrlUtil.download(urlPath,localDir,localFileName);
    }

    @Override
    public ApiRes<OrderNoticeRes> OrderNotice(ApiReq<OrderNoticeReq> request) {
        return super.notifyServiceByDecrypt(request,OrderNoticeRes.class);
    }
}
