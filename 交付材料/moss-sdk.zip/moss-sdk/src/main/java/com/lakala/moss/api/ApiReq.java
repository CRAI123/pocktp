package com.lakala.moss.api;


/**
 * @author Stephen yu
 * @description: 请求消息-消息公共参数
 * @date 2025-02-21
 */
public class ApiReq<T> {

    // 请求消息头
    private ApiReqHead head;
    // 请求消息体
    private T request;
    // 请求消息体密文
    private String requestEncrypted;
    // 请求签名
    private String sign;

    public ApiReqHead getHead() {
        return head;
    }

    public void setHead(ApiReqHead head) {
        this.head = head;
    }

    public T getRequest() {
        return request;
    }

    public void setRequest(T request) {
        this.request = request;
    }

    public String getRequestEncrypted() {
        return requestEncrypted;
    }

    public void setRequestEncrypted(String requestEncrypted) {
        this.requestEncrypted = requestEncrypted;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

}
