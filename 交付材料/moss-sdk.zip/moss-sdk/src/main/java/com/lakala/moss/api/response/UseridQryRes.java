package com.lakala.moss.api.response;

/**
 * 响应参数-用户标识查询
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class UseridQryRes {

    // 银联钱包的userId
    private String user_id;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }
}
