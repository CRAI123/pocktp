package com.lakala.moss.api.params;
/**
 * 请求参数-银联单品营销商品信息
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class AcqAddnDataGoodsInfo {
    // 商品编号
    private String id;
    // 商品名称
    private String name;
    // 商品单价 单位元
    private String price;
    // 商品数量
    private String quantity;
    // 商品类目
    private String category;
    // 附加信息
    private String addninfo;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAddninfo() {
        return addninfo;
    }

    public void setAddninfo(String addninfo) {
        this.addninfo = addninfo;
    }
}
