package com.lakala.moss.api;

/**
 * @author Stephen yu
 * @description: 响应消息-消息头
 * @date 2025-02-21
 */
public class ApiResHead {

    // 响应码，8位字符，000000为成功，其他为失败
    private String code;
    // 响应码描述
    private String desc;
    // 响应时间
    private String serviceTime;
    // 响应流水号，原值返回
    private String serviceSn;
    // 交易服务码
    private String serviceId;
    // 全局流水
    private String sid;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getServiceTime() {
        return serviceTime;
    }

    public void setServiceTime(String serviceTime) {
        this.serviceTime = serviceTime;
    }

    public String getServiceSn() {
        return serviceSn;
    }

    public void setServiceSn(String serviceSn) {
        this.serviceSn = serviceSn;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }
}
