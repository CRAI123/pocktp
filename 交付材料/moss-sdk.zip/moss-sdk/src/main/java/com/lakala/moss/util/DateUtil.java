package com.lakala.moss.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static java.util.Calendar.*;

/**
 * @author Stephen yu
 * @description: 日期工具类
 * @date 2025-02-21
 */
public class DateUtil {
    private static Logger logger = LoggerFactory.getLogger(DateUtil.class);
    private static final Calendar CAL = getInstance();
    private static final Calendar TMP = getInstance();
    public static final String FORMAT1 = "yyyyMMdd";
    public static final String FORMAT2 = "yyyy-MM-dd";
    public static final String FORMAT3 = "yyyyMMddHHmmss";
    public static final String FORMAT4 = "yyyy-MM-dd HH:mm:ss";
    public static final String FORMAT5 = "MMddHHmmss";
    public static final String FORMAT6 = "yyMMddHHmmss";
    public static final int YEAR = Calendar.YEAR;
    public static final int MONTH = Calendar.MONTH;
    public static final int DAY_OF_MONTH = Calendar.DAY_OF_MONTH;
    public static final int HOUR = Calendar.HOUR;
    public static final int MINUTE = Calendar.MINUTE;
    public static final int SECOND = Calendar.SECOND;

    // 静态工具类，防误生成
    private DateUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     * <p>Title: isThisMonth</p>
     * <p>Description: 判断给定日期date是否在当前月内</p>
     *
     * @param date 给定日期
     * @return boolean
     */
    public static boolean isThisMonth(Date date) {
        return isInRange(date, MONTH);
    }

    /**
     * <p>Title: getDateByDayOfMonth</p>
     * <p>Description: 查找指定日期的下一个提醒日</p>
     *
     * @param date 指定日期
     * @param day  提醒日
     * @return Date
     */
    public static Date getDateByDayOfMonth(Date date, int day) {
        synchronized (CAL) {
            CAL.setTime(date);
            int today = CAL.get(DAY_OF_MONTH);
            if (day < today) {
                CAL.add(MONTH, 1);
            }
            CAL.set(DAY_OF_MONTH, day);
            return CAL.getTime();
        }
    }

    /**
     * <p>Title: getDateByDayOfMonth</p>
     * <p>Description: 查找当前日期的下一个提醒日</p>
     *
     * @param day 提醒日
     * @return Date
     */
    public static Date getDateByDayOfMonth(int day) {
        return getDateByDayOfMonth(new Date(), day);
    }

    /**
     * <p>Title: getTheAppointedDayOfTheMonth</p>
     * <p>Description: 根据指定日期和月份换回当月的提醒日期，当提醒日期day大于本月最大天数时，取最大天数。</p>
     *
     * @param month 指定的月份（0-11）
     * @param day   指定的提醒日（1-31）
     * @return int 1-31
     */
    public static int getTheAppointedDayOfTheMonth(int month, int day) {
        synchronized (CAL) {
            CAL.set(MONTH, month);
            int lastDay = CAL.getActualMaximum(DAY_OF_MONTH);
            return day > lastDay ? lastDay : day;
        }
    }

    /**
     * <p>Title: getTheAppointedDayOfTheMonth</p>
     * <p>Description: 根据指定日期返回当前月份的提醒日期，当提醒日期day大于本月最大天数时，取最大天数。</p>
     *
     * @param day 指定的提醒日（1-31）
     * @return int 1-31
     */
    public static int getTheAppointedDayOfTheMonth(int day) {
        synchronized (CAL) {
            resetCalendarWithNowTime();
            int lastDay = CAL.getActualMaximum(DAY_OF_MONTH);
            return day > lastDay ? lastDay : day;
        }
    }

    /**
     * <p>Title: getDayOfMonthOfToday</p>
     * <p>Description: 获取当前日期在本月中是第几天</p>
     *
     * @return int 1-31
     */
    public static int getDayOfMonthOfToday() {
        synchronized (CAL) {
            resetCalendarWithNowTime();
            return CAL.get(DAY_OF_MONTH);
        }
    }

    /**
     * <p>Title: getFate</p>
     * <p>Description: 根据提醒日和指定日期，返回提醒日和指定日期间隔天数，提醒日当天返回0。</p>
     *
     * @param day  提醒日
     * @param date 指定日期
     * @return int 0-30
     */
    public static int getFate(int day, Date date) {
        day = getTheAppointedDayOfTheMonth(day);
        synchronized (CAL) {
            CAL.setTime(date);
            int today = CAL.get(DAY_OF_MONTH);
            int max = CAL.getActualMaximum(DAY_OF_MONTH);
            return (day - today + max) % max;
        }
    }

    /**
     * <p>Title: getFate</p>
     * <p>Description: 根据提醒日，返回下次提醒日距今的天数，提醒日当天返回0。</p>
     *
     * @param day 提醒日
     * @return int 0-30
     */
    public static int getFate(int day) {
        return getFate(day, new Date());
    }

    /**
     * <p>Title: resetCalendarWithNowTime</p>
     * <p>Description: 将cal重置为当前时间。</p>
     */
    private static void resetCalendarWithNowTime() {
        synchronized (CAL) {
            CAL.setTime(new Date());
        }
    }

    /**
     * <p>Title: getFormatDate</p>
     * <p>Description: 把指定日期date转换为指定格式format的日期字符串</p>
     *
     * @param date    指定日期
     * @param pattern 指定格式，可从静态常量中获取
     * @return String
     */
    public static String getFormatDateStr(Date date, String pattern) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        return simpleDateFormat.format(date);
    }

    /**
     * <p>Title: getFormatDateStr</p>
     * <p>Description: 将传入的fm1格式的时间字符串date，转换为fm2格式的字符串类型</p>
     *
     * @param date 指定日期
     * @param fm1  fm1格式
     * @param fm2  fm2格式
     * @return String
     */
    public static String getFormatDateStr(String date, String fm1, String fm2) {
        String oDate = null;
        SimpleDateFormat fmt = new SimpleDateFormat(fm1);
        try {
            Date outDate = fmt.parse(date);
            fmt.applyPattern(fm2);
            oDate = fmt.format(outDate);
        } catch (ParseException e) {
            logger.error("{}", e);
        }
        return oDate;
    }

    /**
     * <p>Title: getSystemDateLongStr</p>
     * <p>Description: 获取当前日期长字符串格式</p>
     *
     * @return String yyyyMMddHHmmss
     */
    public static String getSystemDateLongStr() {
        Date sysDate = new Date();
        return getFormat3DateStr(sysDate);
    }

    /**
     * <p>Title: getSystemDateStr</p>
     * <p>Description: 获取当前日期字符串格式</p>
     *
     * @return String yyyyMMdd
     */
    public static String getSystemDateStr() {
        Date sysDate = new Date();
        return getFormat1DateStr(sysDate);
    }

    /**
     * <p>Title: getSystemDateStr</p>
     * <p>Description: 获取当前日期指定字符串格式</p>
     *
     * @param pattern 指定字符串格式
     * @return String
     */
    public static String getSystemDateStr(String pattern) {
        return getFormatDateStr(new Date(), pattern);
    }

    /**
     * <p>Title: getFormat1DateStr</p>
     * <p>Description: 获取指定日期date字符串格式</p>
     *
     * @param date 指定日期
     * @return String yyyyMMdd
     */
    public static String getFormat1DateStr(Date date) {
        return getFormatDateStr(date, FORMAT1);
    }

    /**
     * <p>Title: getFormat2DateStr</p>
     * <p>Description: 将日期类型date转换为yyyy-MM-dd字符串</p>
     *
     * @param date 目标日期
     * @return String yyyy-MM-dd
     */
    public static String getFormat2DateStr(Date date) {
        return getFormatDateStr(date, FORMAT2);
    }

    /**
     * <p>Title: getFormat3DateStr</p>
     * <p>Description: 将日期类型date转换为yyyyMMddHHmmss字符串</p>
     *
     * @param date 目标日期
     * @return String yyyyMMddHHmmss
     */
    public static String getFormat3DateStr(Date date) {
        return getFormatDateStr(date, FORMAT3);
    }

    /**
     * <p>Title: getFormat4DateStr</p>
     * <p>Description: 将日期类型date转换为yyyy-MM-dd HH:mm:ss字符串</p>
     *
     * @param date 目标日期
     * @return String yyyy-MM-dd HH:mm:ss
     */
    public static String getFormat4DateStr(Date date) {
        return getFormatDateStr(date, FORMAT4);
    }

    /**
     * <p>Title: getFormat5DateStr</p>
     * <p>Description: 将日期类型date转换为MMddHHmmss字符串</p>
     *
     * @param date 目标日期
     * @return String MMddHHmmss
     */
    public static String getFormat5DateStr(Date date) {
        return getFormatDateStr(date, FORMAT5);
    }

    /**
     * <p>Title: getFormat6DateStr</p>
     * <p>Description: 将日期类型date转换为yyMMddHHmmss字符串</p>
     *
     * @param date 目标日期
     * @return String MMddHHmmss
     */
    public static String getFormat6DateStr(Date date) {
        return getFormatDateStr(date, FORMAT6);
    }

    /**
     * <p>Title: getDiffBetweenTwoDate</p>
     * <p>Description: 计算两个日期差几天，也可比较两个日期谁在前，谁在后</p>
     *
     * @param firstDate  第一个日期
     * @param secondDate 第二个日期
     * @return int 天数。如果secondDate在firstDate之前，返回一个负整数；反之返回正整数
     */
    public static int getDiffBetweenTwoDate(Date firstDate, Date secondDate) {
        long seconds = secondDate.getTime() - firstDate.getTime();// 终止日期-起始日期=毫秒
        int diff = (int) (seconds / (24 * 60 * 60 * 1000));// 再除以每天多少毫秒(24*60*60*1000)＝差几天
        return diff;
    }

    /**
     * <p>Title: getDiffBetweenTwoDate</p>
     * <p>Description: 计算两个日期差几天，也可比较两个日期谁在前，谁在后</p>
     *
     * @param firstDate  第一个日期 yyyyMMdd
     * @param secondDate 第二个日期 yyyyMMdd
     * @return int 天数。如果secondDate在firstDate之前，返回一个负整数；反之返回正整数
     */
    public static int getDiffBetweenTwoDate(String firstDate, String secondDate) {
        return getDiffBetweenTwoDate(firstDate, secondDate, FORMAT1);
    }

    /**
     * <p>Title: getDiffBetweenTwoDate</p>
     * <p>Description: 计算两个日期差几天，也可比较两个日期谁在前，谁在后</p>
     *
     * @param firstDate  第一个日期
     * @param secondDate 第二个日期
     * @param format     日期样式
     * @return int 如果secondDate在firstDate之前，返回一个负整数；反之返回正整数
     */
    public static int getDiffBetweenTwoDate(String firstDate, String secondDate, String format) {
        SimpleDateFormat myFormatter = new SimpleDateFormat(format);// 计算两天之差
        Date date1 = null;
        Date date2 = null;
        int diff = 0;
        try {
            date1 = myFormatter.parse(firstDate);// 起始日期
            date2 = myFormatter.parse(secondDate);// 终止日期
            diff = getDiffBetweenTwoDate(date1, date2);
        } catch (ParseException e) {
            logger.error("{}", e);
        }// 起始日期
        return diff;
    }

    /**
     * <p>Title: isLeapYear</p>
     * <p>Description: 判断目标日期所在年是否为闰年</p>
     *
     * @param date 目标日期
     * @return boolean
     */
    public static boolean isLeapYear(Date date) {
        synchronized (CAL) {
            CAL.setTime(date);
            int year = CAL.get(YEAR);
            if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)) {
                return true;
            }
            return false;
        }
    }

    /**
     * <p>Title: getDifferMonth</p>
     * <p>Description: 计算两个日期相差的月份</p>
     *
     * @param startDate 起始日期
     * @param endDate   结束日期
     * @return int 正值：startDate先于endDate；负值：startDate后于endDate
     */
    public static int getDifferMonth(Date startDate, Date endDate) {
        synchronized (CAL) {
            CAL.setTime(startDate);
            TMP.setTime(endDate);
            int differYear = TMP.get(YEAR) - CAL.get(YEAR);
            int differMonth = TMP.get(MONTH) - CAL.get(MONTH);
            return differYear * 12 + differMonth;
        }
    }

    /**
     * <p>Title: getDateByAddYear</p>
     * <p>Description: 指定日期date加year年</p>
     *
     * @param date 指定日期
     * @param year 指定年份
     * @return Date
     */
    public static Date getDateByAddYear(Date date, int year) {
        return getNextRangeDate(date, YEAR, year);
    }

    /**
     * <p>Title: getDateByAddYear</p>
     * <p>Description: 当前日期加year年</p>
     *
     * @param year 指定年份
     * @return Date
     */
    public static Date getDateByAddYear(int year) {
        return getDateByAddYear(new Date(), year);
    }

    /**
     * <p>Title: getDateBeforeXDay</p>
     * <p>Description: 获取指定日期前n日的日期时间</p>
     *
     * @param date   指定日期
     * @param n      提前天数
     * @param format 格式化日期字符串
     * @return String
     */
    public static String getDateBeforeXDay(Date date, int n, String format) {
        Date d = getNextRangeDate(date, DAY_OF_MONTH, -n);
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(d);
    }

    /**
     * <p>Title: getDate</p>
     * <p>Description: 日期字符串转换为日期</p>
     *
     * @param dateStr 日期字符串
     * @param format  转换格式字符串
     * @return Date
     */
    public static Date getDate(String dateStr, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        Date date = null;
        try {
            date = sdf.parse(dateStr);
        } catch (ParseException e) {
            logger.error("{}", e);
        }
        return date;
    }

    /**
     * <p>Title: getBeforeXDay</p>
     * <p>Description: 返回当月指定日期的前X天的值</p>
     *
     * @param target 指定天数
     * @param x      提前天数
     * @return int
     */
    public static int getBeforeXDay(int target, int x) {
        synchronized (CAL) {
            resetCalendarWithNowTime();
            CAL.set(DAY_OF_MONTH, target);
            CAL.add(DAY_OF_MONTH, -x);
            return CAL.get(DAY_OF_MONTH);
        }
    }

    /**
     * <p>Title: dateCompare</p>
     * <p>Description: 比较两个日期是否在某个时间范围内</p>
     *
     * @param date1 日期一
     * @param date2 日期二
     * @param range 范围，Calendar常量或本类常量
     * @param val   范围值
     * @return boolean
     */
    public static boolean dateCompare(Date date1, Date date2, int range, int val) {
        synchronized (CAL) {
            CAL.setTime(date1);
            TMP.setTime(date2);
            if (CAL.before(TMP)) {
                CAL.add(range, val);
                return CAL.after(TMP);
            } else if (CAL.after(TMP)) {
                TMP.add(range, val);
                return CAL.before(TMP);
            } else {
                return true;
            }
        }
    }

    /**
     * <p>Title: dateCompare</p>
     * <p>Description: 判断指定日期与当前日期是否在某个时间范围内</p>
     *
     * @param date  指定日期
     * @param range 范围，Calendar常量或本类常量
     * @param val   范围值
     * @return boolean
     */
    public static boolean dateCompare(Date date, int range, int val) {
        return dateCompare(date, new Date(), range, val);
    }

    /**
     * <p>Title: isInRange</p>
     * <p>Description: 判断指定日期与当前日期是否在指定范围内，当前日期取极值。</p>
     *
     * @param date  指定日期
     * @param range 范围，Calendar常量或本类常量
     * @param val   范围值
     * @return boolean
     */
    public static boolean isInRange(Date date, int range, int val) {
        synchronized (CAL) {
            boolean res = false;
            TMP.setTime(date);
            resetCalendarWithNowTime();
            resetCalendarByRange(CAL, range);
            res = TMP.after(CAL);
            CAL.add(range, val);
            res = res && TMP.before(CAL);
            return res;
        }
    }

    /**
     * <p>Title: resetCalendarByRange</p>
     * <p>Description: 按指定范围range重置cal时间值</p>
     *
     * @param cal   时间类
     * @param range 范围，Calendar常量或本类常量
     */
    public static void resetCalendarByRange(Calendar cal, int range) {
        switch (range) {
            case YEAR:
                cal.set(MONTH, CAL.getActualMinimum(MONTH));
            case MONTH:
                cal.set(DAY_OF_MONTH, CAL.getActualMinimum(DAY_OF_MONTH));
            case DAY_OF_MONTH:
                cal.set(HOUR_OF_DAY, CAL.getActualMinimum(HOUR_OF_DAY));
            case HOUR_OF_DAY:
                cal.set(MINUTE, CAL.getActualMinimum(MINUTE));
            case MINUTE:
                cal.set(SECOND, CAL.getActualMinimum(SECOND));
            case SECOND:
                cal.set(MILLISECOND, CAL.getActualMinimum(MILLISECOND));
        }
    }

    /**
     * <p>Title: isInRange</p>
     * <p>Description: 判断指定日期与当前日期是否在1个单位的范围内，当前日期取极值。</p>
     *
     * @param date  指定日期
     * @param range 范围，Calendar常量或本类常量
     * @return boolean
     */
    public static boolean isInRange(Date date, int range) {
        return isInRange(date, range, 1);
    }

    /**
     * <p>Title: isSameDay</p>
     * <p>Description: 判断指定日期与当前日期是否在同一天内。</p>
     *
     * @param date 指定日期
     * @return boolean
     */
    public static boolean isSameDay(Date date) {
        return isInRange(date, DAY_OF_MONTH);
    }

    /**
     * <p>Title: getNextDate</p>
     * <p>Description: 获取指定日期下一天的日期</p>
     *
     * @param start 指定日期
     * @return Date
     */
    public static Date getNextDate(Date start) {
        return getNextDate(start, 1);
    }

    /**
     * <p>Title: getNextDate</p>
     * <p>Description: 获取指定日期下days天的日期</p>
     *
     * @param start 指定日期
     * @param days  天数
     * @return Date
     */
    public static Date getNextDate(Date start, int days) {
        synchronized (CAL) {
            CAL.setTime(start);
            CAL.add(DAY_OF_MONTH, days);
            return CAL.getTime();
        }
    }

    /**
     * <p>Title: getNextRangeDate</p>
     * <p>Description: 获取指定日期下val个单位指定范围range的日期</p>
     *
     * @param start 指定日期
     * @param range 范围，Calendar常量或本类常量
     * @param val   范围值
     * @return Date
     */
    public static Date getNextRangeDate(Date start, int range, int val) {
        synchronized (CAL) {
            CAL.setTime(start);
            CAL.add(range, val);
            return CAL.getTime();
        }
    }

    /**
     * <p>Title: getDateStrFormatPlusHour</p>
     * <p>Description: 把日期转换为指定格式的日期字符串</p>
     *
     * @param date   指定日期
     * @param format 格式化字符串
     * @param hour   添加时间
     * @return String
     */
    public static String getDateStrFormatPlusHour(Date date, String format,
                                                  int hour) {
        Date nextDate = getNextRangeDate(date, HOUR_OF_DAY, hour);
        return getFormatDateStr(nextDate, format);
    }

    public static String getDateMinu() {//获取当前时间与当日23:59:59的相差分钟数
        Date lastDay = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(lastDay);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 50);
        calendar.set(Calendar.SECOND, 00);
        Date d = calendar.getTime();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long currentTime = 0;
        try {
            currentTime = df.parse(df.format(new Date())).getTime();
            long createTime = df.parse(df.format(d)).getTime();
            long diff = (createTime - currentTime) / 1000 / 60;
            if (diff > 999) {
                diff = 999;
            }
            String minu = String.valueOf(diff);
            return minu;
        } catch (ParseException e) {
            e.printStackTrace();
            return "10";
        }
    }

    public static void main(String[] args) throws ParseException {
        Date lastDay = new Date();
//        Calendar calendar = Calendar.getInstance();
//        calendar.setTime(lastDay);
//        calendar.set(Calendar.HOUR_OF_DAY, 23);
//        calendar.set(Calendar.MINUTE, 59);
//        calendar.set(Calendar.SECOND, 59);
//        Date d = calendar.getTime();
//        System.out.println(""+ d);
//        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        System.out.println(""+ df.format(new Date()));
//        long currentTime = df.parse(df.format(new Date())).getTime();
//        //从对象中拿到时间
//        long createTime = df.parse(df.format(d)).getTime();
//        long diff = (createTime-currentTime)/1000/60;
//        System.out.println("当前系统时间为："+currentTime+"下单时间为："+createTime+"两个时间差为："+diff);
        System.out.println(getNextDate(lastDay, -1));
        System.out.println(getDateMinu());
    }
}
