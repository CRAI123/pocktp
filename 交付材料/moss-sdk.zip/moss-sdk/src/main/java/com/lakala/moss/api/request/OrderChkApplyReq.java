package com.lakala.moss.api.request;

/**
 * 请求参数-申请对账单
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class OrderChkApplyReq {

    // 账单日期，格式：yyyyMMdd，仅支持三个月内的账单下载申请
    private String tran_date;
    // 申请订单号
    private String apply_order_no;

    public String getTran_date() {
        return tran_date;
    }

    public void setTran_date(String tran_date) {
        this.tran_date = tran_date;
    }

    public String getApply_order_no() {
        return apply_order_no;
    }

    public void setApply_order_no(String apply_order_no) {
        this.apply_order_no = apply_order_no;
    }
}
