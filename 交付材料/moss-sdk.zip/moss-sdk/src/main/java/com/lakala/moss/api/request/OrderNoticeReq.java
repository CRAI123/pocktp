package com.lakala.moss.api.request;

/**
 * 请求参数-订单通知
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class OrderNoticeReq {

    // 交易类型。PAY-支付，REFUND-退款
    private String trade_main_type;
    // 商户订单号，根据交易类型不同，或为支付订单号 或为退款订单号
    private String order_no;
    // 商户号
    private String mer_no;
    // 订单金额，单位分
    private String total_amount;
    // 订单标题，用于简单描述订单或商品主题。最多42个字符，如不送，默认显示商户简称
    private String subject;
    // 订单创建时间，格式yyyyMMddHHmmss
    private String order_create_time;
    // 订单有效时间，分钟
    private String order_eff_time;
    // 订单层状态：
    // SUCCESS-已支付
    // PART_REFUND-部分退款 （当商户订单号下存在未全额退款成功的支付流水号时）
    // REFUND-全部退款（当商户订单号下资金全部退完，为全部退款）
    private String order_status;
    // 支付流水号，仅交易类型为PAY-支付时存在。
    private String pay_serial;
    // 对账单流水号，根据交易类型不同，或为支付对账单流水号 或为退款对账单流水号
    private String log_no;
    // 账户端交易订单号，根据交易类型不同，或为支付账户端交易订单号 或为退款账户端交易订单号
    private String acc_trade_no;
    // 支付交易完成时间，或退款交易完成时间。格式yyyyMMddHHmmss
    private String trade_time;
    // 原商户支付订单号，trade_main_type=REFUND时存在该字段
    private String origin_order_no;
    // 原支付流水号，trade_main_type=REFUND时存在该字段
    private String origin_pay_serial;
    // 申请退款订单金额，单位分，trade_main_type=REFUND时存在该字段
    private String refund_amount;
    // 钱包类型；微信：WECHAT 支付宝：ALIPAY 银联云闪付：UQRCODEPAY
    private String account_type;
    // 接入方式：41:NATIVE（（ALIPAY，云闪付支持）51:JSAPI（微信公众号支付，支付宝服务窗支付，银联JS支付）71:微信小程序支付
    private String trans_type;
    // 交易状态：SUCCESS-交易成功
    private String trade_state;
    // 付款银行
    private String bank_type;
    // 银行卡类型,00：借记 01：贷记 02：微信零钱 03：支付宝花呗 04：支付宝其他 05：数字货币 06：拉卡拉支付账户 99：未知
    private String card_type;
    // 付款人实付金额，单位分
    private String payer_amount;
    // 账户端应结订单金额，单位分
    private String acc_settle_amount;
    // 商户优惠金额，单位分
    private String acc_mdiscount_amount;
    // 账户端优惠金额，单位分
    private String acc_discount_amount;
    // 账户端其它优惠金额，单位分
    private String acc_other_discount_amount;
    // 备注信息
    private String remark;
    // 用户标识1,微信sub_open_id 支付宝buyer_logon_id（买家支付宝账号）
    private String user_id1;
    // 用户标识2,微信openId支付宝buyer_user_id 银联user_id
    private String user_id2;
    // 账户端子商户号
    private String sub_mch_id;

    public String getTrade_main_type() {
        return trade_main_type;
    }

    public void setTrade_main_type(String trade_main_type) {
        this.trade_main_type = trade_main_type;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getMer_no() {
        return mer_no;
    }

    public void setMer_no(String mer_no) {
        this.mer_no = mer_no;
    }

    public String getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(String total_amount) {
        this.total_amount = total_amount;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getOrder_create_time() {
        return order_create_time;
    }

    public void setOrder_create_time(String order_create_time) {
        this.order_create_time = order_create_time;
    }

    public String getOrder_eff_time() {
        return order_eff_time;
    }

    public void setOrder_eff_time(String order_eff_time) {
        this.order_eff_time = order_eff_time;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public String getPay_serial() {
        return pay_serial;
    }

    public void setPay_serial(String pay_serial) {
        this.pay_serial = pay_serial;
    }

    public String getLog_no() {
        return log_no;
    }

    public void setLog_no(String log_no) {
        this.log_no = log_no;
    }

    public String getAcc_trade_no() {
        return acc_trade_no;
    }

    public void setAcc_trade_no(String acc_trade_no) {
        this.acc_trade_no = acc_trade_no;
    }

    public String getTrade_time() {
        return trade_time;
    }

    public void setTrade_time(String trade_time) {
        this.trade_time = trade_time;
    }

    public String getOrigin_order_no() {
        return origin_order_no;
    }

    public void setOrigin_order_no(String origin_order_no) {
        this.origin_order_no = origin_order_no;
    }

    public String getOrigin_pay_serial() {
        return origin_pay_serial;
    }

    public void setOrigin_pay_serial(String origin_pay_serial) {
        this.origin_pay_serial = origin_pay_serial;
    }

    public String getRefund_amount() {
        return refund_amount;
    }

    public void setRefund_amount(String refund_amount) {
        this.refund_amount = refund_amount;
    }

    public String getAccount_type() {
        return account_type;
    }

    public void setAccount_type(String account_type) {
        this.account_type = account_type;
    }

    public String getTrans_type() {
        return trans_type;
    }

    public void setTrans_type(String trans_type) {
        this.trans_type = trans_type;
    }

    public String getTrade_state() {
        return trade_state;
    }

    public void setTrade_state(String trade_state) {
        this.trade_state = trade_state;
    }

    public String getBank_type() {
        return bank_type;
    }

    public void setBank_type(String bank_type) {
        this.bank_type = bank_type;
    }

    public String getCard_type() {
        return card_type;
    }

    public void setCard_type(String card_type) {
        this.card_type = card_type;
    }

    public String getPayer_amount() {
        return payer_amount;
    }

    public void setPayer_amount(String payer_amount) {
        this.payer_amount = payer_amount;
    }

    public String getAcc_settle_amount() {
        return acc_settle_amount;
    }

    public void setAcc_settle_amount(String acc_settle_amount) {
        this.acc_settle_amount = acc_settle_amount;
    }

    public String getAcc_mdiscount_amount() {
        return acc_mdiscount_amount;
    }

    public void setAcc_mdiscount_amount(String acc_mdiscount_amount) {
        this.acc_mdiscount_amount = acc_mdiscount_amount;
    }

    public String getAcc_discount_amount() {
        return acc_discount_amount;
    }

    public void setAcc_discount_amount(String acc_discount_amount) {
        this.acc_discount_amount = acc_discount_amount;
    }

    public String getAcc_other_discount_amount() {
        return acc_other_discount_amount;
    }

    public void setAcc_other_discount_amount(String acc_other_discount_amount) {
        this.acc_other_discount_amount = acc_other_discount_amount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getUser_id1() {
        return user_id1;
    }

    public void setUser_id1(String user_id1) {
        this.user_id1 = user_id1;
    }

    public String getUser_id2() {
        return user_id2;
    }

    public void setUser_id2(String user_id2) {
        this.user_id2 = user_id2;
    }

    public String getSub_mch_id() {
        return sub_mch_id;
    }

    public void setSub_mch_id(String sub_mch_id) {
        this.sub_mch_id = sub_mch_id;
    }
}
