package com.lakala.moss.api.response;

import com.lakala.moss.api.params.PayInfo;
import java.util.List;

/**
 * 响应参数-订单查询列表
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class OrderQryListRes {

    // 交易类型。PAY-支付，REFUND-退款
    private String trade_main_type;
    // 商户订单号，根据交易类型不同，或为支付订单号 或为退款订单号
    private String order_no;
    // 原商户支付订单号，trade_main_type=REFUND时存在该字段
    private String origin_order_no;
    // 商户号
    private String mer_no;
    // 订单金额，单位分
    private String total_amount;
    // 订单标题，用于简单描述订单或商品主题。最多42个字符，如不送，默认显示商户简称
    private String subject;
    // 订单创建时间，格式yyyyMMddHHmmss
    private String order_create_time;
    // 订单有效时间，分钟
    private String order_eff_time;
    // 订单层状态：
    //INIT-初始化
    //CREATE-待支付
    //SUCCESS-已支付
    //CLOSE-订单关闭
    //PART_REFUND-部分退款 （当商户订单号下存在未全额退款成功的支付流水号时）
    //REFUND-全部退款（当商户订单号下资金全部退完，为全部退款）
    private String order_status;
    // 接入方式：41:NATIVE（（ALIPAY，云闪付支持）51:JSAPI（微信公众号支付，支付宝服务窗支付，银联JS支付）71:微信小程序支付
    private String trans_type;
    // 支付信息列表
    private List<PayInfo> pay_info_list;

    public String getTrade_main_type() {
        return trade_main_type;
    }

    public void setTrade_main_type(String trade_main_type) {
        this.trade_main_type = trade_main_type;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getOrigin_order_no() {
        return origin_order_no;
    }

    public void setOrigin_order_no(String origin_order_no) {
        this.origin_order_no = origin_order_no;
    }

    public String getMer_no() {
        return mer_no;
    }

    public void setMer_no(String mer_no) {
        this.mer_no = mer_no;
    }

    public String getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(String total_amount) {
        this.total_amount = total_amount;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getOrder_create_time() {
        return order_create_time;
    }

    public void setOrder_create_time(String order_create_time) {
        this.order_create_time = order_create_time;
    }

    public String getOrder_eff_time() {
        return order_eff_time;
    }

    public void setOrder_eff_time(String order_eff_time) {
        this.order_eff_time = order_eff_time;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public String getTrans_type() {
        return trans_type;
    }

    public void setTrans_type(String trans_type) {
        this.trans_type = trans_type;
    }

    public List<PayInfo> getPay_info_list() {
        return pay_info_list;
    }

    public void setPay_info_list(List<PayInfo> pay_info_list) {
        this.pay_info_list = pay_info_list;
    }
}
