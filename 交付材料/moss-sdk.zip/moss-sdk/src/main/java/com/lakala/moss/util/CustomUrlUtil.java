package com.lakala.moss.util;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

/**
 * 工具类 - url下载或上传文件
 *
 * @author Stephen yu
 * @date 2025-02-26
 */
public class CustomUrlUtil {
    private static final Logger logger = LoggerFactory.getLogger(CustomUrlUtil.class);

    /**
     *
     * @param urlPath url链接字符串
     */
    private static URLConnection connectUrlServer(String urlPath){
        logger.info("connect params [urlPath="+urlPath+"]");
        URLConnection conn = null;
        try {
            URL url = new URL(urlPath);
            conn = url.openConnection();

        } catch (MalformedURLException e) {
            logger.error("connect failed,err msg = {}",e.getMessage());
        } catch (IOException e) {
            logger.error("connect failed,err msg = {}",e.getMessage());
        }
        return conn;
    }

    /**
     * 文件下载
     * @param urlPath urlPath地址
     * @param localDir 本地路径
     * @param localFileName 本地文件名称
     */
    public static boolean download(String urlPath,String localDir,String localFileName){
        URLConnection conn = connectUrlServer(urlPath);
        if (conn == null){
            return false;
        }
        InputStream is = null;
        FileOutputStream os = null;
        try {
            is = conn.getInputStream();
            byte[] bs = new byte[1024];
            int len;
            File file = new File(localDir+localFileName);
            os = new FileOutputStream(file);
            while ((len = is.read(bs)) != -1){
                os.write(bs,0,len);
            }
            logger.info("从Url[{}]读取文件到[{}]成功", urlPath, localDir+localFileName);

        } catch (IOException e) {
            logger.error("处理文件流失败.err msg = {}",e.getMessage());
            return false;
        } finally {
            try {
                os.close();
                is.close();
            } catch (IOException e) {
                logger.error("关闭文件流失败.err msg = {}",e.getMessage());
                return false;
            }
        }
        return true;
    }

}
