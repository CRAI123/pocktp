package com.lakala.moss.service;


import com.lakala.moss.api.ApiReq;
import com.lakala.moss.api.ApiRes;
import com.lakala.moss.api.request.*;
import com.lakala.moss.api.response.*;

/**
 * @author Stephen yu
 * @description: api服务接口
 * @date 2025-02-21
 */
public interface IMossApiService {
    /**
     * 订单支付
    */
    ApiRes<OrderPayRes> OrderPay(OrderPayReq req);
    /**
     * 订单查询
     */
    ApiRes<OrderQryListRes> OrderQryList(OrderQryListReq req);
    /**
     * 订单关单
     */
    ApiRes<OrderClsRes> OrderCls(OrderClsReq req);
    /**
     * 订单退款
     */
    ApiRes<OrderRefundRes> OrderRefund(OrderRefundReq req);
    /**
     * 申请对账单
     */
    ApiRes<OrderChkApplyRes> OrderChkApply(OrderChkApplyReq req);
    /**
     * 用户标识查询
     */
    ApiRes<UseridQryRes> UseridQry(UseridQryReq req);
    /**
     * 对账单下载
     */
    boolean ChkDownload(String urlPath,String localDir,String localFileName);
    /**
     * 订单通知
     */
    ApiRes<OrderNoticeRes> OrderNotice(ApiReq<OrderNoticeReq> request);
}
