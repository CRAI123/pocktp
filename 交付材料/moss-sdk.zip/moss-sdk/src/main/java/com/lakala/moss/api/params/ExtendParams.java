package com.lakala.moss.api.params;
/**
 * 请求参数-支付宝业务扩展参数
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class ExtendParams {
    // 系统商编号，该参数作为系统商返佣数据提取的依据，请填写系统商签约协议的 PID
    private String sys_service_provider_id;
    // 点餐场景类型：qr_order（店内扫码点餐），pre_order（预点到店自提），home_delivery （外送到家），direct_payment（直接付款），other（其它）
    private String food_order_type;

    public String getSys_service_provider_id() {
        return sys_service_provider_id;
    }

    public void setSys_service_provider_id(String sys_service_provider_id) {
        this.sys_service_provider_id = sys_service_provider_id;
    }

    public String getFood_order_type() {
        return food_order_type;
    }

    public void setFood_order_type(String food_order_type) {
        this.food_order_type = food_order_type;
    }
}
