package com.lakala.moss.api.params;
/**
 * 请求参数-银联单品营销订单信息
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class AcqAddnDataOrderInfo {
    // 标题
    private String title;
    // 金额
    private String dctAmount;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDctAmount() {
        return dctAmount;
    }

    public void setDctAmount(String dctAmount) {
        this.dctAmount = dctAmount;
    }
}
