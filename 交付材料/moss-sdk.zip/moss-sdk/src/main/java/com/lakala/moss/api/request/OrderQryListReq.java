package com.lakala.moss.api.request;

/**
 * 请求参数-订单查询列表
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class OrderQryListReq {

    // 商户订单号/退款订单号，32位，全局唯一，建议规则：businessChannel+日期时间+序列流水号
    private String order_no;
    // 支付流水号，上送则查账指定的支付流水号
    private String pay_serial;

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getPay_serial() {
        return pay_serial;
    }

    public void setPay_serial(String pay_serial) {
        this.pay_serial = pay_serial;
    }

}
