package com.lakala.moss.api;

/**
 * @author Stephen yu
 * @description: 消息消息-消息公共参数
 * @date @date 2025-02-21
 */
public class ApiRes<T> {

    // 响应消息头
    private ApiResHead head;
    // 响应消息体
    private T response;
    // 响应消息体密文
    private String responseEncrypted;
    // 响应签名
    private String sign;

    public ApiResHead getHead() {
        return head;
    }

    public void setHead(ApiResHead head) {
        this.head = head;
    }

    public T getResponse() {
        return response;
    }

    public void setResponse(T response) {
        this.response = response;
    }

    public String getResponseEncrypted() {
        return responseEncrypted;
    }

    public void setResponseEncrypted(String responseEncrypted) {
        this.responseEncrypted = responseEncrypted;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }
}
