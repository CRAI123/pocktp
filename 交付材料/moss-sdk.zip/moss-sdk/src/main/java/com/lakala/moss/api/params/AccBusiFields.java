package com.lakala.moss.api.params;

import javax.xml.soap.Detail;

/**
 * 请求参数-账户端业务信息域
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class AccBusiFields {
    // 业务扩展参数
    private ExtendParams extend_params;
    // 商品详情
    private GoodsDetail goods_detail;
    // 商户门店编号
    private String store_id;
    // 支付宝禁用支付渠道  credit_group 表示禁用信用支付类（包含信用卡,花呗，花呗分期） pcredit 表示禁用花呗”
    // pcreditpayInstallment 表示禁用花呗分期 creditCard 表示禁用信用卡 如果想禁用多个可在枚举间加,隔开
    private String disable_pay_channels;
    // 商户传入业务信息，应用于安全，营销等参数直传场景，格式为 json 格式。
    // 示例：{“enable_thirdparty_subsidy”:”N”,”source”:”xxxx”},source送值与吱口令生成接口中上送的source对应，
    // 值内容为“inderict_wx_吱口令申领接口中source值”
    private String business_params;
    // 微信分配的子商户公众账号ID，即微信小程序支付-71、公众号支付-51、此参数必传
    private String sub_appid;
    // 商品详情
    private Detail detail;
    // 附加域，该字段主要用于商户携带订单的自定义数据。商户定制字段，直接送到账户端。
    private String attach;
    // 终端设备号(门店号或收银设备ID)，注意：PC网页或JSAPI支付请传”WEB”
    private String device_info;
    // 指定支付方式,no_credit–指定不能使用信用卡支付
    private String limit_pay;
    // 场景信息
    private String scene_info;
    // 银联单品营销订单信息
    private AcqAddnDataOrderInfo acq_addn_data_order_info;
    // 银联单品营销商品信息
    private AcqAddnDataGoodsInfo acq_addn_data_goods_info;
    // 银联前台通知地址
    private String front_url;
    // 银联失败交易前台通知地址
    private String front_fail_url;
    // 用户信息的临时授权码
    private String user_auth_code;

    public ExtendParams getExtend_params() {
        return extend_params;
    }

    public void setExtend_params(ExtendParams extend_params) {
        this.extend_params = extend_params;
    }

    public GoodsDetail getGoods_detail() {
        return goods_detail;
    }

    public void setGoods_detail(GoodsDetail goods_detail) {
        this.goods_detail = goods_detail;
    }

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getDisable_pay_channels() {
        return disable_pay_channels;
    }

    public void setDisable_pay_channels(String disable_pay_channels) {
        this.disable_pay_channels = disable_pay_channels;
    }

    public String getBusiness_params() {
        return business_params;
    }

    public void setBusiness_params(String business_params) {
        this.business_params = business_params;
    }

    public String getSub_appid() {
        return sub_appid;
    }

    public void setSub_appid(String sub_appid) {
        this.sub_appid = sub_appid;
    }

    public Detail getDetail() {
        return detail;
    }

    public void setDetail(Detail detail) {
        this.detail = detail;
    }

    public String getAttach() {
        return attach;
    }

    public void setAttach(String attach) {
        this.attach = attach;
    }

    public String getDevice_info() {
        return device_info;
    }

    public void setDevice_info(String device_info) {
        this.device_info = device_info;
    }

    public String getLimit_pay() {
        return limit_pay;
    }

    public void setLimit_pay(String limit_pay) {
        this.limit_pay = limit_pay;
    }

    public String getScene_info() {
        return scene_info;
    }

    public void setScene_info(String scene_info) {
        this.scene_info = scene_info;
    }

    public AcqAddnDataOrderInfo getAcq_addn_data_order_info() {
        return acq_addn_data_order_info;
    }

    public void setAcq_addn_data_order_info(AcqAddnDataOrderInfo acq_addn_data_order_info) {
        this.acq_addn_data_order_info = acq_addn_data_order_info;
    }

    public AcqAddnDataGoodsInfo getAcq_addn_data_goods_info() {
        return acq_addn_data_goods_info;
    }

    public void setAcq_addn_data_goods_info(AcqAddnDataGoodsInfo acq_addn_data_goods_info) {
        this.acq_addn_data_goods_info = acq_addn_data_goods_info;
    }

    public String getFront_url() {
        return front_url;
    }

    public void setFront_url(String front_url) {
        this.front_url = front_url;
    }

    public String getFront_fail_url() {
        return front_fail_url;
    }

    public void setFront_fail_url(String front_fail_url) {
        this.front_fail_url = front_fail_url;
    }

    public String getUser_auth_code() {
        return user_auth_code;
    }

    public void setUser_auth_code(String user_auth_code) {
        this.user_auth_code = user_auth_code;
    }
}
