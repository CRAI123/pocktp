package com.lakala.moss.service.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.lakala.moss.api.*;
import com.lakala.moss.api.request.OrderNoticeReq;
import com.lakala.moss.api.response.OrderNoticeRes;
import com.lakala.moss.util.*;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.*;

/**
 * @author Stephen yu
 * @description: 基础服务
 * @date 2025-02-21
 */
public abstract class BaseService {

    private static Logger logger = LoggerFactory.getLogger(BaseService.class);

    protected ApiReqHead BuildApiRequestHead(String serivceId) {
        ApiReqHead head = new ApiReqHead();
        head.setVersionId(PropertiesUtil.getStringByKey("api.versionId"));
        head.setServiceId(serivceId);
        head.setChannelId(PropertiesUtil.getStringByKey("api.channelId"));
        head.setRequestTime(DateUtil.getSystemDateLongStr());
        head.setServiceSn(UUID.randomUUID().toString().replaceAll("-", ""));
        head.setBusinessChannel(PropertiesUtil.getStringByKey("api.businessChannel"));
        return head;
    }

    public <T, E> ApiRes<E> postService(T requestObj, Class<E> responseClass, String serivceId) {
        return invokApiByEncrypt(requestObj, responseClass, serivceId);
    }

    private <T, E> ApiRes<E> invokApiByEncrypt(T requestObj, Class<E> responseClass, String serivceId) {
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        ApiRes<E> responseBean = new ApiRes<>();
        // 组装请求消息头对象
        ApiReqHead reqHead = BuildApiRequestHead(serivceId);
        ApiResHead resHead = new ApiResHead();
        resHead.setServiceId(reqHead.getServiceId());
        resHead.setServiceSn(reqHead.getServiceSn());
        resHead.setServiceTime(DateUtil.getSystemDateLongStr());
        try {
            Map<String,String> headMap = ObjectToMapUtils.toMap(reqHead);
            TreeMap<String,String> headTreeMap = new TreeMap<>();
            headTreeMap.putAll(headMap);
            // 组装请求消息体对象
            // 生成加密报文,用moss公钥加密
            String reqParams = gson.toJson(requestObj);
            logger.info("data=" + reqParams);
            String mossPublicKey = PropertiesUtil.getStringByKey("moss.pub.key");
            String requestEncrypted = SecurityUtil.encryptInStringOutBase64(reqParams, mossPublicKey);
            logger.info("encData=" + requestEncrypted);
            // 组装请求消息签名
            // 签名前字段先按key自然排序，用TreeMap实现
            Map<String, String> signMap = new TreeMap<>();
            signMap.put("head", gson.toJson(headTreeMap));
            signMap.put("requestEncrypted", requestEncrypted);
            // 拼接参与签名的字符串,用商户私钥加签
            String signStr = SecurityUtil.getSignSrcSkipNull(signMap, true, "&");
            String merPrivateKey = PropertiesUtil.getStringByKey("mer.pri.key");
            String sign = SecurityUtil.sign(signStr, merPrivateKey);
            // 组装请求消息对象
            Map<String, Object> request = new LinkedHashMap<>();
            request.put("head", headTreeMap);
            request.put("requestEncrypted", requestEncrypted);
            request.put("sign", sign);
            // 最后生成的报文是这样的
            String encReq = gson.toJson(request);
            // 发送post消息
            String url = PropertiesUtil.getStringByKey("api.order.url");
            String encRes = HttpsUtil.doPost(url, encReq);
            if(StringUtils.isBlank(encRes)){
                resHead.setCode(ApiResCode.PA_INSIDE_ERROR.getCode());
                resHead.setDesc(ApiResCode.PA_INSIDE_ERROR.getDesc() + ",响应消息为空");
                responseBean.setHead(resHead);
                return responseBean;
            }
            Map<String, Object> response = gson.fromJson(encRes,Map.class);
            String resSign = (String)response.get("sign");
            String responseEncrypted = (String)response.get("responseEncrypted");
            Map<String,String> resHeadMap = (Map<String,String>)response.get("head");
            if(resHeadMap == null || StringUtils.isBlank(resHeadMap.get("code")) ){
                resHead.setCode(ApiResCode.PA_INSIDE_ERROR.getCode());
                resHead.setDesc(ApiResCode.PA_INSIDE_ERROR.getDesc() + ",响应消息头为空");
                responseBean.setHead(resHead);
                return responseBean;
            }
            responseBean.setHead(gson.fromJson(gson.toJson(resHeadMap), ApiResHead.class));
            if(!ApiResCode.SUCCESS.getCode().equals(resHeadMap.get("code"))){
                return responseBean;
            }
            TreeMap<String,String> resHeadTreeMap = new TreeMap<>();
            resHeadTreeMap.putAll(resHeadMap);
            // 组装响应消息签名
            // 签名前字段先按key自然排序，用TreeMap实现
            Map<String, String> resSignMap = new TreeMap<>();
            resSignMap.put("head", gson.toJson(resHeadTreeMap));
            resSignMap.put("responseEncrypted", responseEncrypted);
            // 拼接参与签名的字符串
            String resSignStr = SecurityUtil.getSignSrcSkipNull(resSignMap, true, "&");
            boolean verifySign = SecurityUtil.verify(resSignStr, resSign, mossPublicKey);
            if(!verifySign){
                resHead.setCode(ApiResCode.PA_INSIDE_ERROR.getCode());
                resHead.setDesc(ApiResCode.PA_INSIDE_ERROR.getDesc() + ",响应消息验签失败");
                responseBean.setHead(resHead);
                return responseBean;
            }
            // 用商户的私要解密数据
            if(StringUtils.isNotBlank(responseEncrypted)){
                String decData = SecurityUtil.decryptInBase64OutString(responseEncrypted, merPrivateKey);
                logger.info("decData={}",decData);
                responseBean.setResponse(gson.fromJson(decData, responseClass));
            }
        } catch (Exception e) {
            logger.error("invokApi error,e={}", e);
            resHead.setCode(ApiResCode.PA_UNKNOWN_ERROR.getCode());
            resHead.setDesc(ApiResCode.PA_UNKNOWN_ERROR.getDesc()+ ",e=" + e.getMessage());
            responseBean.setHead(resHead);
        }
        return responseBean;
    }

    public <T, E> ApiRes<E> notifyServiceByDecrypt(ApiReq<T> request, Class<E> responseClass) {
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        ApiRes<E> res = new ApiRes<>();
        ApiResHead resHead = new ApiResHead();
        resHead.setServiceId(request.getHead().getServiceId());
        resHead.setServiceSn(request.getHead().getServiceSn());
        resHead.setServiceTime(DateUtil.getSystemDateLongStr());
        try {
            Map<String,String> headMap = ObjectToMapUtils.toMap(request.getHead());
            TreeMap<String,String> headTreeMap = new TreeMap<>();
            headTreeMap.putAll(headMap);
            // 组装响应消息签名
            // 签名前字段先按key自然排序，用TreeMap实现
            Map<String, String> signMap = new TreeMap<>();
            signMap.put("head", gson.toJson(headTreeMap));
            signMap.put("requestEncrypted", request.getRequestEncrypted());
            // 拼接参与签名的字符串
            String mossPublicKey = PropertiesUtil.getStringByKey("moss.pub.key");
            String signStr = SecurityUtil.getSignSrcSkipNull(signMap, true, "&");
            logger.info("signStr={}", signStr);
            boolean verifySign = SecurityUtil.verify(signStr, request.getSign(), mossPublicKey);
            if(!verifySign){
                resHead.setCode(ApiResCode.PA_INSIDE_ERROR.getCode());
                resHead.setDesc(ApiResCode.PA_INSIDE_ERROR.getDesc() + ",请求消息验签失败");
                res.setHead(resHead);
                return res;
            }
            // 用商户的私要解密数据
            if(StringUtils.isNotBlank(request.getRequestEncrypted())){
                String merPrivateKey = PropertiesUtil.getStringByKey("mer.pri.key");
                String decData = SecurityUtil.decryptInBase64OutString(request.getRequestEncrypted(), merPrivateKey);
                logger.info("decData={}",decData);
            }
            resHead.setCode(ApiResCode.SUCCESS.getCode());
            resHead.setDesc(ApiResCode.SUCCESS.getDesc());
            res.setHead(resHead);
        } catch (Exception e) {
            logger.error("invokApi error,e={}", e);
            resHead.setCode(ApiResCode.PA_UNKNOWN_ERROR.getCode());
            resHead.setDesc(ApiResCode.PA_UNKNOWN_ERROR.getDesc()+ ",e=" + e.getMessage());
            res.setHead(resHead);
        } finally {

        }
        return res;
    }
}
