package com.lakala.moss.api.params;

/**
 * 请求参数-地址位置信息
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class LocationInfo {
    // 请求方的IP地址，存在必填，格式如36.45.36.95
    private String request_ip;
    // 客户端设备的基站信息
    private String base_station;
    // 商户终端的地理位置，整体格式：纬度,经度，+表示北纬、东经，-表示南纬、 西经。
    // 经度格式：1位正负号+3位整数+1位小数点+5位小数； 纬度格式：1位正负号+2位整数+1位小数点+6位小数；
    // 举例：+31.221345,+121.12345
    private String location;

    public String getRequest_ip() {
        return request_ip;
    }

    public void setRequest_ip(String request_ip) {
        this.request_ip = request_ip;
    }

    public String getBase_station() {
        return base_station;
    }

    public void setBase_station(String base_station) {
        this.base_station = base_station;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
