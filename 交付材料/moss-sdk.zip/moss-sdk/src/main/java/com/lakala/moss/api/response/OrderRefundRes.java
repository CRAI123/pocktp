package com.lakala.moss.api.response;

/**
 * 响应参数-退款交易
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class OrderRefundRes {

    // 商户退款订单号
    private String order_no;
    // 原商户支付订单号
    private String origin_order_no;
    // 原支付流水号
    private String origin_pay_serial;
    // 对账单流水号
    private String log_no;
    // 账户端交易订单号
    private String acc_trade_no;
    // 商户号
    private String mer_no;
    // 交易金额，单位分
    private String total_amount;
    // 申请退款金额,单位分
    private String refund_amount;
    // 实际退款金额,单位分
    private String payer_amount;
    // 退款时间,yyyyMMddHHmmss
    private String trade_time;
    // 交易状态
    //INIT-初始化；
    //SUCCESS-交易成功；
    //FAIL-交易失败；
    //DEAL-交易处理中/未知；
    //TIMEOUT-超时未知；
    //EXCEPTION-异常；
    private String trade_state;

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getOrigin_order_no() {
        return origin_order_no;
    }

    public void setOrigin_order_no(String origin_order_no) {
        this.origin_order_no = origin_order_no;
    }

    public String getOrigin_pay_serial() {
        return origin_pay_serial;
    }

    public void setOrigin_pay_serial(String origin_pay_serial) {
        this.origin_pay_serial = origin_pay_serial;
    }

    public String getLog_no() {
        return log_no;
    }

    public void setLog_no(String log_no) {
        this.log_no = log_no;
    }

    public String getAcc_trade_no() {
        return acc_trade_no;
    }

    public void setAcc_trade_no(String acc_trade_no) {
        this.acc_trade_no = acc_trade_no;
    }

    public String getMer_no() {
        return mer_no;
    }

    public void setMer_no(String mer_no) {
        this.mer_no = mer_no;
    }

    public String getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(String total_amount) {
        this.total_amount = total_amount;
    }

    public String getRefund_amount() {
        return refund_amount;
    }

    public void setRefund_amount(String refund_amount) {
        this.refund_amount = refund_amount;
    }

    public String getPayer_amount() {
        return payer_amount;
    }

    public void setPayer_amount(String payer_amount) {
        this.payer_amount = payer_amount;
    }

    public String getTrade_time() {
        return trade_time;
    }

    public void setTrade_time(String trade_time) {
        this.trade_time = trade_time;
    }

    public String getTrade_state() {
        return trade_state;
    }

    public void setTrade_state(String trade_state) {
        this.trade_state = trade_state;
    }
}
