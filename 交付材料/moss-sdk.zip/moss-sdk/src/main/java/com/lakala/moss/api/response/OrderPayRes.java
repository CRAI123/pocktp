package com.lakala.moss.api.response;

import com.lakala.moss.api.params.AccRespFields;

/**
 * 响应参数-订单支付
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class OrderPayRes {

    // 商户订单号
    private String order_no;
    // 支付流水号
    private String pay_serial;
    // 账户端的商户单号
    private String trade_no;
    // 对账单流水号
    private String log_no;
    // 支付场景 0-拉起收银台 1-独立支付API
    private String pay_scene;
    // 账户端子商户号
    private String sub_mch_id;
    // [微信小程序/微信公众号/支付宝生活号]支付时返回,预下单Id，JSAPI支付方式时返回
    private String prepay_id;
    // 账户端返回信息域
    private AccRespFields acc_resp_fields;
    // 收银台地址url，可嵌入至H5、PC或集成小程序场景中
    private String counter_url;

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getPay_serial() {
        return pay_serial;
    }

    public void setPay_serial(String pay_serial) {
        this.pay_serial = pay_serial;
    }

    public String getTrade_no() {
        return trade_no;
    }

    public void setTrade_no(String trade_no) {
        this.trade_no = trade_no;
    }

    public String getLog_no() {
        return log_no;
    }

    public void setLog_no(String log_no) {
        this.log_no = log_no;
    }

    public String getPay_scene() {
        return pay_scene;
    }

    public void setPay_scene(String pay_scene) {
        this.pay_scene = pay_scene;
    }

    public String getSub_mch_id() {
        return sub_mch_id;
    }

    public void setSub_mch_id(String sub_mch_id) {
        this.sub_mch_id = sub_mch_id;
    }

    public String getPrepay_id() {
        return prepay_id;
    }

    public void setPrepay_id(String prepay_id) {
        this.prepay_id = prepay_id;
    }

    public AccRespFields getAcc_resp_fields() {
        return acc_resp_fields;
    }

    public void setAcc_resp_fields(AccRespFields acc_resp_fields) {
        this.acc_resp_fields = acc_resp_fields;
    }

    public String getCounter_url() {
        return counter_url;
    }

    public void setCounter_url(String counter_url) {
        this.counter_url = counter_url;
    }
}
