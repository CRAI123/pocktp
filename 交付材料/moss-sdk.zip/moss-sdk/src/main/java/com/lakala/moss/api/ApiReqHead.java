package com.lakala.moss.api;

/**
 * @author Stephen yu
 * @description: 请求消息-消息头
 * @date 2025-02-21
 */
public class ApiReqHead {

    // 版本号，值为1.0
    private String versionId;
    // 交易服务码
    private String serviceId;
    // 技术渠道号，值为API
    private String channelId;
    // 请求时间，格式：yyyyMMddHHmmss
    private String requestTime;
    // 交易流水号，请求方生成，建议使用32位UUID
    private String serviceSn;
    // 业务渠道号，即为MOSS为客户生成的唯一客户编号（同为开发应用Appid，在工作台-开发者中心获取）
    private String businessChannel;

    private String sid;
    private String org;
    private String accessToken;

    public String getVersionId() {
        return versionId;
    }

    public void setVersionId(String versionId) {
        this.versionId = versionId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(String requestTime) {
        this.requestTime = requestTime;
    }

    public String getServiceSn() {
        return serviceSn;
    }

    public void setServiceSn(String serviceSn) {
        this.serviceSn = serviceSn;
    }

    public String getBusinessChannel() {
        return businessChannel;
    }

    public void setBusinessChannel(String businessChannel) {
        this.businessChannel = businessChannel;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getOrg() {
        return org;
    }

    public void setOrg(String org) {
        this.org = org;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}
