package com.lakala.moss.api.params;

import com.google.gson.annotations.SerializedName;

/**
 * 请求参数-账户端返回信息域
 *
 * @author Stephen yu
 * @date 2024-12-17
 */
public class AccRespFields {
    // 商户可用此参数自定义去生成二维码后展示出来进行扫码支付；支付宝(41-NATIVE)场景下返回
    private String code;
    // 商户收款二维码图片。Base64编码，暂无；支付宝(41-NATIVE)场景下返回
    private String code_image;
    // 支付签名信息；微信(71-小程序)微信(51-JSAPI)场景下返回
    private String pay_sign;
    // 小程序id；微信(71-小程序)微信(51-JSAPI)场景下返回
    private String app_id;
    // 时间戳；微信(71-小程序)微信(51-JSAPI)场景下返回
    private String time_stamp;
    // 随机字符串；微信(71-小程序)微信(51-JSAPI)场景下返回
    private String nonce_str;
    // 订单详情扩展字符串；微信(71-小程序)微信(51-JSAPI)场景下返回
    @SerializedName("package")
    private String spackage;
    // 签名方式；微信(71-小程序)微信(51-JSAPI)场景下返回
    private String sign_type;
    // 银联JS支付返回重定向地址；银联二维码(51-JSAPI)场景下返回
    private String redirect_url;

    // 订单查询特有
    // [支付宝]商户门店编号
    private String store_id;
    // [支付宝]交易支付使用的资金渠道
    private String fund_bill_list;
    // [微信]活动 ID,在账户端商户后台配置的批次 ID
    private String acc_activity_id;
    // [微信]优惠功能信息
    private String promotion_detail;
    // [云闪付]银联单品营销 附加数据，参与单品营销优惠时返回
    private String up_iss_addn_data;
    // [云闪付]银联优惠信息/出资方信息，参与单品营销优惠时返回
    private String up_coupon_info;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode_image() {
        return code_image;
    }

    public void setCode_image(String code_image) {
        this.code_image = code_image;
    }

    public String getPay_sign() {
        return pay_sign;
    }

    public void setPay_sign(String pay_sign) {
        this.pay_sign = pay_sign;
    }

    public String getApp_id() {
        return app_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public String getTime_stamp() {
        return time_stamp;
    }

    public void setTime_stamp(String time_stamp) {
        this.time_stamp = time_stamp;
    }

    public String getNonce_str() {
        return nonce_str;
    }

    public void setNonce_str(String nonce_str) {
        this.nonce_str = nonce_str;
    }

    public String getSpackage() {
        return spackage;
    }

    public void setSpackage(String spackage) {
        this.spackage = spackage;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getRedirect_url() {
        return redirect_url;
    }

    public void setRedirect_url(String redirect_url) {
        this.redirect_url = redirect_url;
    }

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getFund_bill_list() {
        return fund_bill_list;
    }

    public void setFund_bill_list(String fund_bill_list) {
        this.fund_bill_list = fund_bill_list;
    }

    public String getAcc_activity_id() {
        return acc_activity_id;
    }

    public void setAcc_activity_id(String acc_activity_id) {
        this.acc_activity_id = acc_activity_id;
    }

    public String getPromotion_detail() {
        return promotion_detail;
    }

    public void setPromotion_detail(String promotion_detail) {
        this.promotion_detail = promotion_detail;
    }

    public String getUp_iss_addn_data() {
        return up_iss_addn_data;
    }

    public void setUp_iss_addn_data(String up_iss_addn_data) {
        this.up_iss_addn_data = up_iss_addn_data;
    }

    public String getUp_coupon_info() {
        return up_coupon_info;
    }

    public void setUp_coupon_info(String up_coupon_info) {
        this.up_coupon_info = up_coupon_info;
    }
}
