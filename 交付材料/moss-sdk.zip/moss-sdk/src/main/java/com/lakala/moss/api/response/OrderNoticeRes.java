package com.lakala.moss.api.response;

/**
 * 响应参数-订单通知
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class OrderNoticeRes {



}
