package com.lakala.moss.api.params;

/**
 * 请求参数-支付信息
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class PayInfo {
    // 支付流水号，仅交易类型为PAY-支付时存在。
    private String pay_serial;
    // 对账单流水号，根据交易类型不同，或为支付对账单流水号 或为退款对账单流水号
    private String log_no;
    // 账户端交易订单号，根据交易类型不同，或为支付账户端交易订单号 或为退款账户端交易订单号
    private String acc_trade_no;
    // 支付交易完成时间，或退款交易完成时间。格式yyyyMMddHHmmss
    private String trade_time;
    // 原支付流水号，trade_main_type=REFUND时存在该字段
    private String origin_pay_serial;
    // 申请退款订单金额，单位分，trade_main_type=REFUND时存在该字段
    private String refund_amount;
    // 钱包类型；微信：WECHAT 支付宝：ALIPAY 银联云闪付：UQRCODEPAY
    private String account_type;
    // 交易状态
    //INIT-初始化
    //CREATE-待支付
    //SUCCESS-交易成功
    //FAIL-交易失败
    //DEAL-交易处理中
    //CLOSE-订单关闭
    //PART_REFUND-部分退款
    //REFUND-全部退款
    //EXPIRE-已过期
    //UNKNOWN-未知状态
    private String trade_state;
    // 付款银行
    private String bank_type;
    // 银行卡类型,00：借记 01：贷记 02：微信零钱 03：支付宝花呗 04：支付宝其他 05：数字货币 06：拉卡拉支付账户 99：未知
    private String card_type;
    // 付款人实付金额，单位分
    private String payer_amount;
    // 账户端应结订单金额，单位分
    private String acc_settle_amount;
    // 商户优惠金额，单位分
    private String acc_mdiscount_amount;
    // 账户端优惠金额，单位分
    private String acc_discount_amount;
    // 账户端其它优惠金额，单位分
    private String acc_other_discount_amount;
    // 备注信息
    private String remark;
    // 用户标识1,微信sub_open_id 支付宝buyer_logon_id（买家支付宝账号）
    private String user_id1;
    // 用户标识2,微信openId支付宝buyer_user_id 银联user_id
    private String user_id2;
    // 账户端子商户号
    private String sub_mch_id;

    public String getPay_serial() {
        return pay_serial;
    }

    public void setPay_serial(String pay_serial) {
        this.pay_serial = pay_serial;
    }

    public String getLog_no() {
        return log_no;
    }

    public void setLog_no(String log_no) {
        this.log_no = log_no;
    }

    public String getAcc_trade_no() {
        return acc_trade_no;
    }

    public void setAcc_trade_no(String acc_trade_no) {
        this.acc_trade_no = acc_trade_no;
    }

    public String getTrade_time() {
        return trade_time;
    }

    public void setTrade_time(String trade_time) {
        this.trade_time = trade_time;
    }

    public String getOrigin_pay_serial() {
        return origin_pay_serial;
    }

    public void setOrigin_pay_serial(String origin_pay_serial) {
        this.origin_pay_serial = origin_pay_serial;
    }

    public String getRefund_amount() {
        return refund_amount;
    }

    public void setRefund_amount(String refund_amount) {
        this.refund_amount = refund_amount;
    }

    public String getAccount_type() {
        return account_type;
    }

    public void setAccount_type(String account_type) {
        this.account_type = account_type;
    }

    public String getTrade_state() {
        return trade_state;
    }

    public void setTrade_state(String trade_state) {
        this.trade_state = trade_state;
    }

    public String getBank_type() {
        return bank_type;
    }

    public void setBank_type(String bank_type) {
        this.bank_type = bank_type;
    }

    public String getCard_type() {
        return card_type;
    }

    public void setCard_type(String card_type) {
        this.card_type = card_type;
    }

    public String getPayer_amount() {
        return payer_amount;
    }

    public void setPayer_amount(String payer_amount) {
        this.payer_amount = payer_amount;
    }

    public String getAcc_settle_amount() {
        return acc_settle_amount;
    }

    public void setAcc_settle_amount(String acc_settle_amount) {
        this.acc_settle_amount = acc_settle_amount;
    }

    public String getAcc_mdiscount_amount() {
        return acc_mdiscount_amount;
    }

    public void setAcc_mdiscount_amount(String acc_mdiscount_amount) {
        this.acc_mdiscount_amount = acc_mdiscount_amount;
    }

    public String getAcc_discount_amount() {
        return acc_discount_amount;
    }

    public void setAcc_discount_amount(String acc_discount_amount) {
        this.acc_discount_amount = acc_discount_amount;
    }

    public String getAcc_other_discount_amount() {
        return acc_other_discount_amount;
    }

    public void setAcc_other_discount_amount(String acc_other_discount_amount) {
        this.acc_other_discount_amount = acc_other_discount_amount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getUser_id1() {
        return user_id1;
    }

    public void setUser_id1(String user_id1) {
        this.user_id1 = user_id1;
    }

    public String getUser_id2() {
        return user_id2;
    }

    public void setUser_id2(String user_id2) {
        this.user_id2 = user_id2;
    }

    public String getSub_mch_id() {
        return sub_mch_id;
    }

    public void setSub_mch_id(String sub_mch_id) {
        this.sub_mch_id = sub_mch_id;
    }
}
