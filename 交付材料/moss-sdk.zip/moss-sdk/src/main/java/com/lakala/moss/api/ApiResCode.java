package com.lakala.moss.api;

/**
 * @author Stephen yu
 * @description: 接口结果码定义
 * @date 2025-02-21
 */
public enum ApiResCode {
    SUCCESS("000000", "交易成功"),
    PA_INSIDE_ERROR("MOSS0001", "交易处理失败"),
    PA_TIMEOUT_ERROR("MOSS0002", "交易通讯异常"),
    PA_UNKNOWN_ERROR("MOSS0003", "交易处理异常"),
    PA_PARAM_ERROR("MOSS0004", "参数校验错误"),
    PA_REPEAT_ERROR("MOSS0005", "订单重复"),
    PA_NOEXIST_ERROR("MOSS0006", "订单不存在")
    ;

    private String code;
    private String desc;

    ApiResCode(final String code, final String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return this.code;
    }

    public String getDesc() {
        return this.desc;
    }
}
