package com.lakala.moss.api.request;

import com.lakala.moss.api.params.LocationInfo;

/**
 * 请求参数-退款交易
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class OrderRefundReq {

    // 退款订单号
    private String order_no;
    // 原商户支付订单号
    private String origin_order_no;
    // 原支付流水号（可指定需要退款的支付流水号）
    private String origin_pay_serial;
    // 退款金额，以分为单位
    private String refund_amount;
    // 退款原因描述
    private String refund_reason;
    // 地址位置信息，风控要求必送
    private LocationInfo location_info;

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getOrigin_order_no() {
        return origin_order_no;
    }

    public void setOrigin_order_no(String origin_order_no) {
        this.origin_order_no = origin_order_no;
    }

    public String getOrigin_pay_serial() {
        return origin_pay_serial;
    }

    public void setOrigin_pay_serial(String origin_pay_serial) {
        this.origin_pay_serial = origin_pay_serial;
    }

    public String getRefund_amount() {
        return refund_amount;
    }

    public void setRefund_amount(String refund_amount) {
        this.refund_amount = refund_amount;
    }

    public String getRefund_reason() {
        return refund_reason;
    }

    public void setRefund_reason(String refund_reason) {
        this.refund_reason = refund_reason;
    }

    public LocationInfo getLocation_info() {
        return location_info;
    }

    public void setLocation_info(LocationInfo location_info) {
        this.location_info = location_info;
    }

}
