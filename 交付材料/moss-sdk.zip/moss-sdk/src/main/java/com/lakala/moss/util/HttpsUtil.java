package com.lakala.moss.util;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Stephen yu
 * @description: HTTPS工具类
 * @date 2025-02-21
 */
public class HttpsUtil {

	private static Logger logger = LoggerFactory.getLogger(HttpsUtil.class);

	private HttpsUtil(){}

	/**
	 * post请求
	 * @param url
	 * @param jsonStrParams
	 * @return
	 * @throws Exception
	 */
	public static String doPost(String url, String jsonStrParams) throws Exception {
		logger.info("url=" + url);
		logger.info("request message=" + jsonStrParams);
		HttpClient httpClient = null;
		HttpPost httpPost = null;
		String result = null;
		HttpResponse response = null;

		httpClient = new SSLClient();
		httpPost = new HttpPost(url);
		httpPost.addHeader("Content-Type", "application/json");
		StringEntity se = new StringEntity(jsonStrParams, "UTF-8");
		se.setContentType("text/json");
		se.setContentEncoding(new BasicHeader("Content-Type", "application/json"));
		httpPost.setEntity(se);
		response = httpClient.execute(httpPost);
		if (response != null) {
			HttpEntity resEntity = response.getEntity();
			if (resEntity != null) {
				result = EntityUtils.toString(resEntity, "UTF-8");
			}
		}
		logger.info("response message=" + result);

		return result;
	}

	/**
	 * post请求
	 * @param url
	 * @param jsonStrParams
	 * @return
	 * @throws Exception
	 */
	public static String doPost2(String url, String jsonStrParams) throws Exception {

		logger.info("request：" + jsonStrParams);
		HttpClient httpClient = null;
		HttpPost httpPost = null;
		String result = null;
		HttpResponse response = null;

		httpClient = new SSLClient();
		httpPost = new HttpPost(url);
		httpPost.addHeader("Content-Type", "application/json");
		httpPost.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36");
		StringEntity se = new StringEntity(jsonStrParams, "UTF-8");
		se.setContentType("text/json");
		se.setContentEncoding(new BasicHeader("Content-Type", "application/json"));
		httpPost.setEntity(se);
		response = httpClient.execute(httpPost);
		if (response != null) {
			HttpEntity resEntity = response.getEntity();
			if (resEntity != null) {
				result = EntityUtils.toString(resEntity, "UTF-8");
			}
		}
		logger.info("response：" + result);

		return result;
	}

	/**
	 * get请求
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public static String doGet(String url) throws Exception {
		logger.info("对账文件Url : " + url);
		HttpClient httpClient = null;
		HttpGet httpGet = null;
		String result = null;
		HttpResponse response = null;

		httpClient = new SSLClient();
		httpGet = new HttpGet(url);
		response = httpClient.execute(httpGet);
		if (response != null) {
			HttpEntity resEntity = response.getEntity();
			if (resEntity != null) {
				result = EntityUtils.toString(resEntity, "GBK");
			}
		}
		logger.info("对账文件内容 : " + result);

		return result;
	}
}