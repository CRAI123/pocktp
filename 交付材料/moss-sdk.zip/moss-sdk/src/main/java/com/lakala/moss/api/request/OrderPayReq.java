package com.lakala.moss.api.request;

import com.lakala.moss.api.params.AccBusiFields;
import com.lakala.moss.api.params.LocationInfo;

/**
 * 请求参数-订单支付
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class OrderPayReq {

    // 商户订单号，32位，全局唯一，建议规则：businessChannel+日期时间+序列流水号
    private String order_no;
    // 订单总金额，分为单位，整数。示例：1元应填写 100
    private String total_amount;
    // 商户号，平台客户下所发展的商户，通过MOSS平台新增商户产生，M+8位数字；
    private String mer_no;
    // 订单备注信息
    private String remark;
    // 后端支付结果通知url，支付结果通知的平台后台回调地址，通知url必须为外网可访问的url，不能携带参数
    private String notify_url;
    // 支付场景 0-标准收银台 1-独立支付API
    private String pay_scene;
    // 钱包类型：
    //pay_scene=0为非必传，可多传，表示为指定收银台内展示的支付方式；当pay_scene=1模式时必传单个支付方式。
    //ALIPAY：支付宝
    //WECHAT：微信
    //UQRCODEPAY：银联云闪付
    private String account_type;
    // 订单标题，用于简单描述订单或商品主题。最多42个字符，如不送，默认显示商户简称
    private String subject;
    // 订单有效期,格式yyyyMMddHHmmss,建议不超过15分钟。不传值则默认5分钟。
    private String order_eff_time;
    // 当客户微信公众号/支付宝生活号/云闪付H5支付场景时，拉起MOSS-H5收银台支付成功后，跳转至客户指定的URL页面地址；
    private String callback_url;
    // 接入方式：
    //41:NATIVE（（ALIPAY，云闪付支持）
    //51:JSAPI（微信公众号支付，支付宝服务窗支付，银联JS支付）
    //71:微信小程序支付
    private String trans_type;
    // 地址位置信息，风控要求必送
    private LocationInfo location_info;
    // 用户在钱包侧唯一标识，微信支付宝侧为openid，云闪付为userid。trans_type为51情况下传入。
    private String user_id;
    // 账户端业务信息域，不同类型的account_type对应不同的账户端，需要填写以下不同的信息
    private AccBusiFields acc_busi_fields;

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(String total_amount) {
        this.total_amount = total_amount;
    }

    public String getMer_no() {
        return mer_no;
    }

    public void setMer_no(String mer_no) {
        this.mer_no = mer_no;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getNotify_url() {
        return notify_url;
    }

    public void setNotify_url(String notify_url) {
        this.notify_url = notify_url;
    }

    public String getPay_scene() {
        return pay_scene;
    }

    public void setPay_scene(String pay_scene) {
        this.pay_scene = pay_scene;
    }

    public String getAccount_type() {
        return account_type;
    }

    public void setAccount_type(String account_type) {
        this.account_type = account_type;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getOrder_eff_time() {
        return order_eff_time;
    }

    public void setOrder_eff_time(String order_eff_time) {
        this.order_eff_time = order_eff_time;
    }

    public String getCallback_url() {
        return callback_url;
    }

    public void setCallback_url(String callback_url) {
        this.callback_url = callback_url;
    }

    public String getTrans_type() {
        return trans_type;
    }

    public void setTrans_type(String trans_type) {
        this.trans_type = trans_type;
    }

    public LocationInfo getLocation_info() {
        return location_info;
    }

    public void setLocation_info(LocationInfo location_info) {
        this.location_info = location_info;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public AccBusiFields getAcc_busi_fields() {
        return acc_busi_fields;
    }

    public void setAcc_busi_fields(AccBusiFields acc_busi_fields) {
        this.acc_busi_fields = acc_busi_fields;
    }

}
