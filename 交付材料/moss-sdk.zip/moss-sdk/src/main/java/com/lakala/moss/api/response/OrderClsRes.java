package com.lakala.moss.api.response;

/**
 * 响应参数-关单交易
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class OrderClsRes {

    // 原商户支付订单号
    private String origin_order_no;
    // 交易时间，格式yyyyMMddHHmmss
    private String trade_time;

    public String getOrigin_order_no() {
        return origin_order_no;
    }

    public void setOrigin_order_no(String origin_order_no) {
        this.origin_order_no = origin_order_no;
    }

    public String getTrade_time() {
        return trade_time;
    }

    public void setTrade_time(String trade_time) {
        this.trade_time = trade_time;
    }

}
