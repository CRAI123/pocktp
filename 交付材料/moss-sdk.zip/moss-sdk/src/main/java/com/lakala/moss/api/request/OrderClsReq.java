package com.lakala.moss.api.request;

import com.lakala.moss.api.params.LocationInfo;

/**
 * 请求参数-关单交易
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class OrderClsReq {

    // 原商户支付订单号
    private String origin_order_no;
    // 地址位置信息，风控要求必送
    private LocationInfo location_info;

    public String getOrigin_order_no() {
        return origin_order_no;
    }

    public void setOrigin_order_no(String origin_order_no) {
        this.origin_order_no = origin_order_no;
    }

    public LocationInfo getLocation_info() {
        return location_info;
    }

    public void setLocation_info(LocationInfo location_info) {
        this.location_info = location_info;
    }

}
