package com.lakala.moss.api.response;

/**
 * 响应参数-申请对账单
 *
 * @author Stephen yu
 * @date 2025-02-21
 */
public class OrderChkApplyRes {

    // 文件下载地址，供下一步请求账单文件的下载地址，该地址5min内有效。
    private String down_load_url;
    // 申请订单号
    private String apply_order_no;

    public String getDown_load_url() {
        return down_load_url;
    }

    public void setDown_load_url(String down_load_url) {
        this.down_load_url = down_load_url;
    }

    public String getApply_order_no() {
        return apply_order_no;
    }

    public void setApply_order_no(String apply_order_no) {
        this.apply_order_no = apply_order_no;
    }
}
