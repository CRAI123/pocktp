package com.lakala.moss.util;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

/**
 * @author Stephen yu
 * @description: 配置文件util
 * @date 2025-02-21
 */
public class PropertiesUtil {

    private static final Logger logger = LoggerFactory.getLogger(PropertiesUtil.class);

    /**
     * 私有化构造函数，防止类被实例化
     */
    private PropertiesUtil(String filePath, String encode) {
        File file = new File(filePath);
        File[] array = file.listFiles();
        for(File childfile : array) {
            String childFileName = childfile.getName();
            if(!childFileName.endsWith("properties")) continue;
            loadConfigProperties(childFileName, encode);
        }
    }
    /**
     * 存放配置文件的所有的key-value
     * 以这种方式存储是为了防止多个配置文件间存在key冲突
     */
    private Map<String, HashMap<String,String>> allParam = new HashMap<String, HashMap<String, String>>();
    /**
     * 默认的properties文件名
     */
    private static final String DEFAULT_PROPERTIES_NAME = "moss-sdk.properties";
    /**
     * 解析properties文件默认编码
     */
    private static final String DEFAULT_ENCODE = "UTF-8";
    /**
     * 解析properties文件编码
     */
    private static String fileEncode = null;
    /**
     * properties文件所在的地址
     */
    private static String propertiesParentPath = null;
    /**
     * 根据文件名称-key，返回相应key的值
     * 文件名默认为config.properties，文件编码默认为UTF-8
     */
    public static Integer getIntegerByKey(String key) {
        return Integer.parseInt(getStringByKey(DEFAULT_PROPERTIES_NAME, key, DEFAULT_ENCODE));
    }
    /**
     * 根据文件名称-key，返回相应key的值，文件编码默认为UTF-8
     * @param fileName 文件名
     * @param key properties文件中key的名称
     */
    public static Integer getIntegerByKey(String fileName, String key) {
        return Integer.parseInt(getStringByKey(fileName, key, DEFAULT_ENCODE));
    }
    /**
     * 根据文件名称-key，返回相应key的值
     * @param fileName 文件名
     * @param key properties文件中key的名称
     * @param encode 文件编码
     */
    public static Integer getIntegerByKey(String fileName, String key, String encode) {
        return Integer.parseInt(getStringByKey(fileName, key, encode));
    }
    /**
     * 根据文件名称-key，返回相应key的值
     * 文件名默认为config.properties，文件编码默认为UTF-8
     */
    public static Boolean getBooleanByKey(String key) {
        return Boolean.parseBoolean(getStringByKey(DEFAULT_PROPERTIES_NAME, key, DEFAULT_ENCODE));
    }
    /**
     * 根据文件名称-key，返回相应key的值，文件编码默认为UTF-8
     * @param fileName 文件名
     * @param key properties文件中key的名称
     */
    public static Boolean getBooleanByKey(String fileName, String key) {
        return Boolean.parseBoolean(getStringByKey(fileName, key, DEFAULT_ENCODE));
    }
    /**
     * 根据文件名称-key，返回相应key的值
     * @param fileName 文件名
     * @param key properties文件中key的名称
     * @param encode 文件编码
     */
    public static Boolean getBooleanByKey(String fileName, String key, String encode) {
        return Boolean.parseBoolean(getStringByKey(fileName, key, encode));
    }
    /**
     * 根据文件名称-key，返回相应key的值
     * 文件名默认为config.properties，文件编码默认为UTF-8
     */
    public static Long getLongByKey(String key) {
        return Long.parseLong(getStringByKey(DEFAULT_PROPERTIES_NAME, key, DEFAULT_ENCODE));
    }
    /**
     * 根据文件名称-key，返回相应key的值，文件编码默认为UTF-8
     * @param fileName 文件名
     * @param key properties文件中key的名称
     */
    public static Long getLongByKey(String fileName, String key) {
        return Long.parseLong(getStringByKey(fileName, key, DEFAULT_ENCODE));
    }
    /**
     * 根据文件名称-key，返回相应key的值
     * @param fileName 文件名
     * @param key properties文件中key的名称
     * @param encode 文件编码
     */
    public static Long getLongByKey(String fileName, String key, String encode) {
        return Long.parseLong(getStringByKey(fileName, key, encode));
    }
    /**
     * 根据文件名称-key，返回相应key的值
     * 文件名默认为config.properties，文件编码默认为UTF-8
     */
    public static String getStringByKey(String key){
        return getStringByKey(DEFAULT_PROPERTIES_NAME, key, DEFAULT_ENCODE);
    }
    /**
     * 根据文件名，key返回value值，文件编码默认为UTF-8
     */
    public static String getStringByKey(String fileName, String key) {
        return getStringByKey(fileName, key, DEFAULT_ENCODE);
    }
    /**
     * 根据文件名，key，编码返回value值
     */
    public static String getStringByKey(String fileName, String key, String encode) {
        String propertiesPath = System.getProperty("moss.sdk.config");
        if(StringUtils.isBlank(propertiesPath)){
            propertiesPath = PropertiesUtil.class.getClassLoader().getResource(fileName).getPath();
        }
        propertiesParentPath = propertiesPath.replace(fileName, "");
        fileEncode = encode;
        return PropertiesUtilHolder.instance.allParam.get(fileName).get(key);
    }
    /**
     * 静态内部类，单例模式，保证只有一个实例变量
     */
    private static class PropertiesUtilHolder {
        private static PropertiesUtil instance = new PropertiesUtil(propertiesParentPath, fileEncode);
    }
    /**
     * 加载配置文件，需要进行加锁
     */
    private void loadConfigProperties(String fileName, String encode) {
        InputStream in = null;
        try {
            Properties p = new Properties();
            File file = new File(fileName);
            if(file.exists()) {
                p.load(new FileInputStream(file));
            } else {
                in = PropertiesUtil.class.getClassLoader().getResourceAsStream(fileName);
                // 解决中文乱码
                BufferedReader bf = new BufferedReader(new InputStreamReader(in, encode));
                p.load(bf);
            }
            Set<Entry<Object, Object>> allKey = p.entrySet();
            HashMap<String, String> paramMap = new HashMap<String, String>();
            for (Entry<Object, Object> entry : allKey) {
                paramMap.put(String.valueOf(entry.getKey()), String.valueOf(entry.getValue()));
            }
            allParam.put(fileName, paramMap);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if(in != null) in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
